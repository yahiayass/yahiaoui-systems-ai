
import React, { useEffect, useRef } from 'react';

interface NeuralBackgroundProps {
  state?: 'disconnected' | 'connecting' | 'connected' | 'error';
  isSpeaking?: boolean;
}

export const NeuralBackground: React.FC<NeuralBackgroundProps> = ({ state = 'disconnected', isSpeaking = false }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mouseRef = useRef({ x: 0, y: 0 });
  
  // Store props in ref to access them in the animation loop without re-triggering useEffect
  const propsRef = useRef({ state, isSpeaking });

  useEffect(() => {
    propsRef.current = { state, isSpeaking };
  }, [state, isSpeaking]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = canvas.width = window.innerWidth;
    let height = canvas.height = window.innerHeight;

    // --- CONFIGURATION ---
    const isMobile = window.innerWidth < 768;
    
    // Layer 1: Neurons (Structure)
    const neuronCount = isMobile ? 60 : 160; 
    const mouseDistance = 250; 
    
    // Layer 2: Data Particles
    const particleCount = isMobile ? 15 : 40;
    const trailLength = 15;

    // Visual State for Transitions
    const visualState = {
        speedMultiplier: 0.2,
        r: 40, g: 20, b: 20 // Default disconnected color (Dark)
    };

    interface Neuron {
      x: number;
      y: number;
      vx: number;
      vy: number;
      size: number;
      baseX?: number;
      baseY?: number;
    }

    interface DataParticle {
      x: number;
      y: number;
      vx: number;
      vy: number;
      history: {x: number, y: number}[];
      size: number;
      speed: number;
      angle: number;
    }

    const neurons: Neuron[] = [];
    const particles: DataParticle[] = [];

    // Initialize Neurons
    for (let i = 0; i < neuronCount; i++) {
      neurons.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.5, // Base speed, will be scaled
        vy: (Math.random() - 0.5) * 0.5,
        size: Math.random() * 1.5 + 1
      });
    }

    // Initialize Data Particles
    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: 0,
        vy: 0,
        history: [],
        size: Math.random() * 1.5 + 0.5,
        speed: Math.random() * 0.5 + 0.2,
        angle: Math.random() * Math.PI * 2
      });
    }

    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current.x = e.clientX;
      mouseRef.current.y = e.clientY;
    };

    window.addEventListener('mousemove', handleMouseMove);

    const animate = () => {
      const { state: currentState, isSpeaking: currentSpeaking } = propsRef.current;

      // --- DETERMINE TARGET VISUALS ---
      let targetSpeed = 0.2;
      let targetR = 40;
      let targetG = 20;
      let targetB = 20;

      if (currentState === 'connecting') {
          targetSpeed = 0.6;
          targetR = 200; targetG = 100; targetB = 50; // Amber/Gold pulse
      } else if (currentState === 'connected') {
          if (currentSpeaking) {
             targetSpeed = 1.0;
             targetR = 239; targetG = 68; targetB = 68; // Brand Red (Active)
          } else {
             targetSpeed = 0.4;
             targetR = 100; targetG = 15; targetB = 15; // Deep Red (Mystery/Listening)
          }
      } else if (currentState === 'error') {
          targetSpeed = 0.1;
          targetR = 150; targetG = 0; targetB = 0; // Dark Red
      }

      // --- LERP TRANSITIONS ---
      const ease = 0.05;
      visualState.speedMultiplier += (targetSpeed - visualState.speedMultiplier) * ease;
      visualState.r += (targetR - visualState.r) * ease;
      visualState.g += (targetG - visualState.g) * ease;
      visualState.b += (targetB - visualState.b) * ease;

      // Clear with trail effect
      ctx.fillStyle = 'rgba(0, 0, 0, 0.2)'; 
      ctx.fillRect(0, 0, width, height);
      
      const currentRGB = `${Math.round(visualState.r)}, ${Math.round(visualState.g)}, ${Math.round(visualState.b)}`;

      // --- LAYER 1: NEURONS ---
      neurons.forEach(n => {
        // Apply dynamic speed multiplier
        n.x += n.vx * visualState.speedMultiplier;
        n.y += n.vy * visualState.speedMultiplier;

        if (n.x < 0 || n.x > width) n.vx *= -1;
        if (n.y < 0 || n.y > height) n.vy *= -1;
      });

      // Neuron Interaction with Mouse
      neurons.forEach((n) => {
        const dx = mouseRef.current.x - n.x;
        const dy = mouseRef.current.y - n.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        let proximity = 0;

        if (dist < mouseDistance) {
           proximity = 1 - dist / mouseDistance;
           const force = proximity * 0.05; 
           n.x += dx * force;
           n.y += dy * force;
        }

        // Draw Neuron Body
        ctx.beginPath();
        const drawSize = n.size + (proximity * 2);
        ctx.arc(n.x, n.y, drawSize, 0, Math.PI * 2);
        
        // Dynamic Color
        const alpha = 0.5 + proximity * 0.5;
        ctx.fillStyle = `rgba(${currentRGB}, ${alpha})`; 
        ctx.fill();
      });


      // --- LAYER 2: DATA PARTICLES ---
      particles.forEach(p => {
        p.vx = Math.cos(p.angle) * p.speed * visualState.speedMultiplier;
        p.vy = Math.sin(p.angle) * p.speed * visualState.speedMultiplier;

        // Mouse Reactivity
        const dx = mouseRef.current.x - p.x;
        const dy = mouseRef.current.y - p.y;
        const dist = Math.sqrt(dx*dx + dy*dy);
        let isExcited = false;

        if (dist < 200) {
            isExcited = true;
            p.x -= dx * 0.005; 
            p.y -= dy * 0.005;
        }

        p.x += p.vx;
        p.y += p.vy;

        if (p.x < 0) p.x = width;
        if (p.x > width) p.x = 0;
        if (p.y < 0) p.y = height;
        if (p.y > height) p.y = 0;

        // Slow direction change
        if (Math.random() < 0.01) {
            p.angle += (Math.random() - 0.5) * 0.2;
        }

        p.history.push({ x: p.x, y: p.y });
        if (p.history.length > trailLength) {
            p.history.shift();
        }

        // Draw Trail
        if (p.history.length > 1) {
            ctx.beginPath();
            ctx.moveTo(p.history[0].x, p.history[0].y);
            for (let i = 1; i < p.history.length; i++) {
                ctx.lineTo(p.history[i].x, p.history[i].y);
            }
            
            const gradient = ctx.createLinearGradient(
                p.history[0].x, p.history[0].y, 
                p.x, p.y
            );
            gradient.addColorStop(0, `rgba(${currentRGB}, 0)`);
            gradient.addColorStop(1, isExcited ? 'rgba(255, 255, 255, 0.8)' : `rgba(${currentRGB}, 0.6)`);
            
            ctx.strokeStyle = gradient;
            ctx.lineWidth = isExcited ? 1.5 : 0.8;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            ctx.stroke();
        }

        // Draw Head
        ctx.beginPath();
        ctx.arc(p.x, p.y, isExcited ? 1.5 : 0.8, 0, Math.PI * 2);
        ctx.fillStyle = isExcited ? '#ffffff' : `rgb(${currentRGB})`;
        ctx.fill();
      });

      requestAnimationFrame(animate);
    };

    const animId = requestAnimationFrame(animate);

    const handleResize = () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);
    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  return (
    <div className="fixed inset-0 z-0 bg-black pointer-events-none">
       {/* Background noise texture handled in parent/App */}
       <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-neutral-900/30 via-black to-black opacity-90"></div>
       <canvas ref={canvasRef} className="absolute inset-0" />
    </div>
  );
};

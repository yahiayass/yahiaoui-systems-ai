
import React from 'react';

interface HeaderProps {
  lang: 'fr' | 'en';
  setLang: (lang: 'fr' | 'en') => void;
}

export const Header: React.FC<HeaderProps> = ({ lang, setLang }) => {
  const scrollToSection = (id: string) => (e: React.MouseEvent) => {
    e.preventDefault();
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToTop = (e: React.MouseEvent) => {
    e.preventDefault();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const t = {
    home: lang === 'fr' ? 'Accueil' : 'Home',
    about: lang === 'fr' ? 'À Propos' : 'About',
    services: lang === 'fr' ? 'Services' : 'Services',
    projects: lang === 'fr' ? 'Projets' : 'Projects',
    pricing: lang === 'fr' ? 'Tarifs' : 'Pricing',
    cta: lang === 'fr' ? 'Devis Gratuit' : 'Get a Quote'
  };

  return (
    <header className="fixed top-0 w-full z-40 px-6 py-4 flex justify-between items-center bg-black/50 backdrop-blur-md border-b border-white/5 transition-all">
      <div className="flex items-center gap-3 cursor-pointer" onClick={scrollToTop}>
        {/* Logo YS - Black & Red Theme */}
        <div className="w-10 h-10 bg-black border border-brand-600 rounded-lg flex items-center justify-center shadow-[0_0_15px_rgba(220,38,38,0.4)] group hover:shadow-[0_0_25px_rgba(220,38,38,0.6)] transition-all duration-300">
          <span className="text-lg font-black tracking-tighter text-brand-500 group-hover:text-white transition-colors">YS</span>
        </div>
        <div className="hidden sm:block">
          <h1 className="text-lg font-bold tracking-tight text-white leading-none">Yahiaoui Systems</h1>
          <p className="text-[10px] text-brand-500 font-bold tracking-[0.2em] uppercase">Digital Agency</p>
        </div>
      </div>
      
      <div className="flex items-center gap-6">
        <nav className="hidden md:flex gap-8 text-sm font-medium text-neutral-400">
          <a href="#" onClick={scrollToTop} className="hover:text-brand-500 transition-colors text-white">{t.home}</a>
          <a href="#about" onClick={scrollToSection('about')} className="hover:text-brand-500 transition-colors">{t.about}</a>
          <a href="#services" onClick={scrollToSection('services')} className="hover:text-brand-500 transition-colors">{t.services}</a>
          <a href="#projects" onClick={scrollToSection('projects')} className="hover:text-brand-500 transition-colors">{t.projects}</a>
          <a href="#pricing" onClick={scrollToSection('pricing')} className="hover:text-brand-500 transition-colors">{t.pricing}</a>
        </nav>
        
        <div className="flex items-center gap-3">
            {/* Language Switcher */}
            <button 
                onClick={() => setLang(lang === 'fr' ? 'en' : 'fr')}
                className="flex items-center gap-1 text-xs font-bold uppercase tracking-wider border border-neutral-800 bg-neutral-900/50 px-2 py-1.5 rounded-md hover:border-brand-500 transition-all"
            >
                <span className={lang === 'fr' ? 'text-white' : 'text-neutral-600'}>FR</span>
                <span className="text-neutral-700">/</span>
                <span className={lang === 'en' ? 'text-white' : 'text-neutral-600'}>EN</span>
            </button>

            <a href="#contact" onClick={scrollToSection('contact')} className="hidden sm:block px-5 py-2 rounded-full border border-brand-500/30 bg-brand-500/10 text-brand-400 text-xs font-bold uppercase tracking-wider hover:bg-brand-600 hover:text-white transition-all shadow-[0_0_10px_rgba(239,68,68,0.1)] hover:shadow-[0_0_20px_rgba(239,68,68,0.4)]">
              {t.cta}
            </a>
        </div>
      </div>
    </header>
  );
};

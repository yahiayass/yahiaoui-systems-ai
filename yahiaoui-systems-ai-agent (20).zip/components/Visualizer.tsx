
import React from 'react';

interface VisualizerProps {
  isActive: boolean;
  volume: number; // 0 to 255
  state: 'disconnected' | 'connecting' | 'connected' | 'error';
  mode?: 'full' | 'widget'; 
}

// 5 bars with a bell curve distribution for a more natural voice look
const BAR_MULTIPLIERS = [0.25, 0.55, 1.0, 0.55, 0.25];
const BASE_HEIGHT = 4;
const MAX_ADDED_HEIGHT = 45; 

export const Visualizer: React.FC<VisualizerProps> = ({ isActive, volume, state, mode = 'widget' }) => {
  // Clamp volume and apply a curve to make it more responsive to lower volumes (logarithmic feel)
  const safeVol = Math.min(Math.max(volume, 0), 255);
  // Power 0.7 boosts lower volumes slightly so the visualizer isn't dead for quiet voices
  const normalizedVol = Math.pow(safeVol / 255, 0.7); 

  // Determine if there is meaningful audio activity (User or AI)
  const hasAudio = safeVol > 10;
  const isVisuallyActive = isActive || hasAudio;

  const containerSize = mode === 'widget' ? 'w-40 h-40' : 'w-64 h-64';
  const orbSize = mode === 'widget' ? 'w-20 h-20' : 'w-32 h-32';

  return (
    <div className={`relative ${containerSize} flex items-center justify-center select-none pointer-events-none`}>
      {/* Background Ambience / Glow - RED THEME */}
      <div 
        className={`absolute inset-0 rounded-full blur-3xl transition-all duration-1000 ease-in-out ${
          state === 'connected' ? 'bg-brand-600/20' : 
          state === 'connecting' ? 'bg-amber-500/10' : 
          state === 'error' ? 'bg-red-500/40' : 
          'bg-transparent'
        }`}
        style={{
          transform: state === 'connected' ? `scale(${1 + normalizedVol * 0.3})` : 'scale(0.8)',
          opacity: state === 'connected' ? 0.2 + (normalizedVol * 0.3) : 
                   state === 'error' ? 0.5 : 0
        }}
      />

      {/* Main Container Ring */}
      <div 
        className={`absolute inset-0 rounded-full border-2 transition-all duration-700 ${
          state === 'connected' ? 'border-brand-500/20' : 'border-neutral-800/0'
        }`}
        style={{
          transform: state === 'connected' ? `scale(${1 + normalizedVol * 0.05})` : 'scale(1)'
        }}
      />

      {/* Rotating Loader Ring */}
      <div 
        className={`absolute inset-4 rounded-full border border-dashed transition-all duration-1000 ${
          state === 'connected' 
            ? 'border-brand-500/40 animate-[spin_12s_linear_infinite]' 
            : state === 'connecting' 
              ? 'border-brand-500/60 animate-spin'
              : 'border-transparent'
        }`}
      />

      {/* Center Orb with Hover Effects */}
      <div 
        className={`relative z-10 ${orbSize} rounded-full flex items-center justify-center transition-all duration-500 shadow-2xl backdrop-blur-md overflow-hidden border pointer-events-auto
           hover:scale-105 cursor-pointer group
           ${
             state === 'connected' 
             ? 'bg-gradient-to-br from-black via-brand-950 to-black border-brand-500/50 shadow-brand-900/50' 
             : state === 'connecting'
             ? 'bg-neutral-950 border-brand-500/40 shadow-brand-500/20'
             : state === 'error'
             ? 'bg-neutral-950 border-red-500 shadow-[0_0_30px_rgba(255,0,0,0.6)]'
             : 'bg-neutral-900 border-neutral-700 shadow-black/80 hover:border-brand-500/50'
        }`}
      >
         {/* Icon: Disconnected */}
         {state === 'disconnected' && (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-neutral-600 transition-colors duration-300 group-hover:text-brand-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
            </svg>
         )}

         {/* Icon: Connecting */}
         {state === 'connecting' && (
           <div className="w-8 h-8 border-2 border-brand-500 border-t-transparent rounded-full animate-spin"></div>
         )}
         
         {/* Icon: Error */}
         {state === 'error' && (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-red-500 animate-pulse" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
         )}

         {/* Connected Waveform */}
         {state === 'connected' && (
           <div className="flex gap-1.5 items-center justify-center h-full w-full px-3">
             {BAR_MULTIPLIERS.map((multiplier, i) => {
               // Idle animation: A very slow, gentle sine wave
               // We offset the time by index to create a wave effect
               const idleOffset = Math.sin((Date.now() / 1200) + i) * 2; 
               const idleHeight = BASE_HEIGHT + Math.abs(idleOffset);

               // Active animation: Based on volume
               // We add a small amount of random-ish variation using sin so bars don't look frozen at constant volume
               const activeVariation = Math.sin((Date.now() / 200) + i) * 3; 
               const targetHeight = BASE_HEIGHT + (normalizedVol * MAX_ADDED_HEIGHT * multiplier) + (normalizedVol * activeVariation);

               // Use max to ensure we don't go below base
               const finalHeight = Math.max(BASE_HEIGHT, hasAudio ? targetHeight : idleHeight);

               return (
                 <div 
                   key={i}
                   className="w-1.5 rounded-full shadow-[0_0_8px_rgba(239,68,68,0.4)]"
                   style={{
                     height: `${finalHeight}px`,
                     backgroundColor: isVisuallyActive ? '#ef4444' : '#7f1d1d',
                     // 150ms is the sweet spot for voice: responsive but smooths out the jitter
                     transition: 'height 150ms ease-out, background-color 300ms ease', 
                     opacity: isVisuallyActive ? 1 : 0.6, 
                   }}
                 />
               );
             })}
           </div>
         )}
      </div>

      {/* Status Ring Pulse (when active) */}
      {state === 'connected' && isVisuallyActive && (
          <div className="absolute inset-0 rounded-full border border-brand-500/20 animate-ping pointer-events-none duration-[2000ms]" />
      )}
    </div>
  );
};

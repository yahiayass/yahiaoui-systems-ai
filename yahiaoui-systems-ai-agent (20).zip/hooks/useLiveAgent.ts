
import { useState, useRef, useEffect, useCallback } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { base64ToUint8Array, decodeAudioData, createPcmBlob, downsampleTo16k } from '../utils/audioUtils';

// Identity Data
const MALE_NAMES = ['Thomas', 'Julien', 'Nicolas', 'Pierre', 'Lucas', 'Maxime', 'Antoine', 'David'];
const FEMALE_NAMES = ['Sarah', 'Julie', 'Marie', 'Laura', 'Emma', 'Sophie', 'Céline', 'Anaïs'];
const SURNAMES = ['Durand', 'Morel', 'Petit', 'Dubois', 'Lefebvre', 'Leroy', 'Roux', 'Mercier', 'Isoulet'];

// Types
export type AgentState = 'disconnected' | 'connecting' | 'connected' | 'error';

export interface ChatMessage {
  id: string;
  role: 'user' | 'agent';
  text: string;
  videoUrl?: string; // URL for Veo generated video
  imageUrl?: string; // URL for Gemini generated image
}

interface UseLiveAgentReturn {
  state: AgentState;
  connect: (userLang?: 'fr' | 'en') => Promise<void>;
  disconnect: () => void;
  sendText: (text: string) => void;
  generateVideo: (file: File, prompt?: string) => Promise<void>;
  generateImage: (prompt: string, size?: '1K' | '2K' | '4K') => Promise<void>;
  toggleMute: () => void;
  isMuted: boolean;
  isSpeaking: boolean;
  volume: number;
  messages: ChatMessage[];
  agentName: string | null;
  hasMicAccess: boolean;
  resumeAudio: () => void;
}

export const useLiveAgent = (): UseLiveAgentReturn => {
  const [state, setState] = useState<AgentState>('disconnected');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [volume, setVolume] = useState(0);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [agentName, setAgentName] = useState<string | null>(null);
  const [hasMicAccess, setHasMicAccess] = useState(true);
  
  // Mute State
  const [isMuted, setIsMuted] = useState(false);
  const isMutedRef = useRef(false); // Ref for audio loop access
  
  // Refs
  const sessionPromiseRef = useRef<Promise<any> | null>(null);
  const isConnectingRef = useRef(false); // Lock to prevent double connection
  const reconnectAttemptsRef = useRef(0);
  const retryTimeoutRef = useRef<any>(null);
  
  // Switch default to stable exp model
  const currentModelRef = useRef('gemini-2.0-flash-exp');
  
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const sourceNodeRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const activeSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const nextStartTimeRef = useRef<number>(0);
  
  // Transcription accumulators
  const currentOutputTranscriptionRef = useRef<string>('');
  const currentInputTranscriptionRef = useRef<string>('');
  
  // Analysers
  const outputAnalyserRef = useRef<AnalyserNode | null>(null);
  const inputAnalyserRef = useRef<AnalyserNode | null>(null);
  
  const animationFrameRef = useRef<number | null>(null);

  const initAudioContexts = () => {
    // Input Context: Do NOT force sampleRate here, let browser decide (often 48k or 44.1k)
    // We will downsample manually later. Forcing it can cause failure on some devices.
    if (!inputAudioContextRef.current) {
      inputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      inputAnalyserRef.current = inputAudioContextRef.current.createAnalyser();
      inputAnalyserRef.current.fftSize = 256;
      inputAnalyserRef.current.smoothingTimeConstant = 0.5;
    }

    if (!outputAudioContextRef.current) {
      outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({
        sampleRate: 24000, // Gemini Output is usually 24k
      });
      outputAnalyserRef.current = outputAudioContextRef.current.createAnalyser();
      outputAnalyserRef.current.fftSize = 256;
      outputAnalyserRef.current.smoothingTimeConstant = 0.5;
      outputAnalyserRef.current.connect(outputAudioContextRef.current.destination);
    }
  };
  
  // Helper to unlock audio on mobile/safari
  const resumeAudio = useCallback(() => {
     const ctx = outputAudioContextRef.current;
     if (ctx && ctx.state === 'suspended') {
        ctx.resume().catch(e => console.error("Audio resume failed", e));
     }
     const inCtx = inputAudioContextRef.current;
     if (inCtx && inCtx.state === 'suspended') {
        inCtx.resume().catch(e => console.error("Input Audio resume failed", e));
     }
  }, []);

  const toggleMute = useCallback(() => {
    resumeAudio(); // Ensure context is running on click
    setIsMuted(prev => {
        const next = !prev;
        isMutedRef.current = next;
        return next;
    });
  }, [resumeAudio]);

  const updateVisualizer = () => {
    if (state === 'connected') {
      let currentVol = 0;
      let isAiTalking = false;

      if (outputAnalyserRef.current) {
        const dataArray = new Uint8Array(outputAnalyserRef.current.frequencyBinCount);
        outputAnalyserRef.current.getByteFrequencyData(dataArray);
        const average = dataArray.reduce((acc, val) => acc + val, 0) / dataArray.length;
        if (average > 2) { 
          currentVol = average;
          isAiTalking = true;
        }
      }

      // Only check input volume if mic is accessible AND not muted
      if (!isAiTalking && inputAnalyserRef.current && hasMicAccess && !isMutedRef.current) {
        const dataArray = new Uint8Array(inputAnalyserRef.current.frequencyBinCount);
        inputAnalyserRef.current.getByteFrequencyData(dataArray);
        const average = dataArray.reduce((acc, val) => acc + val, 0) / dataArray.length;
        currentVol = average;
      }

      setVolume(currentVol);
      setIsSpeaking(isAiTalking);
      
      animationFrameRef.current = requestAnimationFrame(updateVisualizer);
    }
  };

  const generateIdentity = () => {
    const isFemale = Math.random() > 0.5;
    const firstNameList = isFemale ? FEMALE_NAMES : MALE_NAMES;
    const firstName = firstNameList[Math.floor(Math.random() * firstNameList.length)];
    
    let lastName = SURNAMES[Math.floor(Math.random() * SURNAMES.length)];
    
    // SPECIFIC PERSONA: Pierre Isoulet
    if (firstName === 'Pierre') {
        lastName = 'Isoulet';
    }
    
    // SÉLECTION DES VOIX :
    // Aoede (Femme) et Charon (Homme) sont les voix les plus neutres et "posées".
    // Elles s'adaptent le mieux à l'instruction "Accent Français Natif".
    const voiceName = isFemale ? 'Aoede' : 'Charon'; 
    
    return {
      fullName: `${firstName} ${lastName}`,
      voiceName,
      firstName
    };
  };

  const connect = useCallback(async (userLang: 'fr' | 'en' = 'fr') => {
    // Prevent double connection attempts
    if (isConnectingRef.current) return;
    
    // Clear any pending retry
    if (retryTimeoutRef.current) clearTimeout(retryTimeoutRef.current);

    try {
      const apiKey = process.env.API_KEY;
      if (!apiKey) {
        console.error("API Key is missing from process.env.API_KEY");
        alert("Erreur critique : Clé API manquante. Veuillez vérifier la configuration.");
        setState('error');
        return;
      }

      isConnectingRef.current = true;
      setState('connecting');
      initAudioContexts();
      setMessages([]); 
      setIsMuted(false);
      isMutedRef.current = false;

      // Generate Identity for this session
      const identity = generateIdentity();
      setAgentName(identity.fullName);

      // Try to get microphone access, but don't fail if denied
      let stream: MediaStream | null = null;
      try {
        stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        streamRef.current = stream;
        setHasMicAccess(true);
      } catch (err) {
        console.warn("Microphone access denied or dismissed. Switching to text-only mode / receive-only audio.");
        setHasMicAccess(false);
        streamRef.current = null;
      }

      const ai = new GoogleGenAI({ apiKey });
      
      // Use fallback model if necessary or if fresh start
      if (reconnectAttemptsRef.current === 0) {
        currentModelRef.current = 'gemini-2.0-flash-exp';
      }

      sessionPromiseRef.current = ai.live.connect({
        model: currentModelRef.current,
        config: {
          responseModalities: [Modality.AUDIO],
          outputAudioTranscription: {}, 
          inputAudioTranscription: {},
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: identity.voiceName } },
          },
          systemInstruction: `
            CONTEXTE :
            Tu es ${identity.fullName}, Consultant Senior chez "Yahiaoui Systems".
            
            RÈGLES ABSOLUES SUR LA VOIX ET L'ACCENT (CRITIQUE) :
            1. TU ES UN LOCUTEUR FRANÇAIS NATIF.
            2. Tu n'as AUCUN accent anglais ou américain.
            3. Ton intonation est standard, parisienne, posée et élégante.
            4. Ne sois PAS "enthousiaste" à la manière américaine. Sois calme et professionnel.
            5. Prononce les noms propres et techniques avec une phonétique française naturelle.
            6. Prononce "Yahiaoui" comme "Ya-ya-oui".
            
            LANGUE :
            - Langue principale : ${userLang === 'fr' ? 'Français' : 'Anglais'}.
            - Même en parlant de termes techniques (Web, IA), garde une prononciation française naturelle.
            
            SCÉNARIO :
            Tu dois convaincre l'interlocuteur que l'automatisation et le design web sont essentiels.
            Services : Création Web, Automatisation IA (n8n, Chatbots), Design UI/UX.
            
            RÉPONSES :
            Sois concis, pertinent et chaleureux (mais sans excès d'enthousiasme).
            Si l'utilisateur demande de modifier le site, note-le simplement pour plus tard.
          `,
        },
        callbacks: {
          onopen: () => {
            console.log(`Gemini Live Connection Opened (Model: ${currentModelRef.current})`);
            setState('connected');
            isConnectingRef.current = false;
            reconnectAttemptsRef.current = 0; // Reset retries on success
            
            const greeting = userLang === 'fr' 
              ? `Bonjour, je suis ${identity.fullName} de chez Yahiaoui Systems. Je suis votre expert en automatisation. Comment puis-je vous aider ?`
              : `Hello, I am ${identity.fullName} from Yahiaoui Systems. How can I help you today?`;

            setMessages([{
              id: 'init', 
              role: 'agent', 
              text: greeting
            }]);

            // Only setup audio input processing if we have a stream
            if (inputAudioContextRef.current && streamRef.current && inputAnalyserRef.current) {
              const source = inputAudioContextRef.current.createMediaStreamSource(streamRef.current);
              sourceNodeRef.current = source;
              source.connect(inputAnalyserRef.current);

              // 4096 buffer size is standard for ScriptProcessor
              const processor = inputAudioContextRef.current.createScriptProcessor(4096, 1, 1);
              processorRef.current = processor;

              processor.onaudioprocess = (e) => {
                // MUTE CHECK: Do not send audio if muted
                if (isMutedRef.current) return;

                const inputData = e.inputBuffer.getChannelData(0);
                
                // CRITICAL: Downsample input audio (e.g. 48000Hz) to 16000Hz required by Gemini
                // Without this, the audio is unintelligible to the AI
                const currentSampleRate = inputAudioContextRef.current?.sampleRate || 48000;
                const downsampledData = downsampleTo16k(inputData, currentSampleRate);
                
                const pcmBlob = createPcmBlob(downsampledData);
                
                sessionPromiseRef.current?.then((session) => {
                  session.sendRealtimeInput({ media: pcmBlob });
                });
              };

              source.connect(processor);
              processor.connect(inputAudioContextRef.current.destination);
            }
            
            // Visualizer runs regardless, but handles 0 input volume if no mic
            updateVisualizer();
          },
          onmessage: async (message: LiveServerMessage) => {
            const ctx = outputAudioContextRef.current;
            if (!ctx) return;

            if (message.serverContent?.outputTranscription) {
              const text = message.serverContent.outputTranscription.text;
              currentOutputTranscriptionRef.current += text;
            }

            if (message.serverContent?.inputTranscription) {
              const text = message.serverContent.inputTranscription.text;
              currentInputTranscriptionRef.current += text;
            }

            if (message.serverContent?.turnComplete) {
              if (currentInputTranscriptionRef.current.trim()) {
                const text = currentInputTranscriptionRef.current;
                setMessages(prev => {
                  const lastMsg = prev[prev.length - 1];
                  if (lastMsg && lastMsg.role === 'user' && lastMsg.text === text) return prev;
                  return [...prev, { id: Date.now().toString() + '-user', role: 'user', text }];
                });
                currentInputTranscriptionRef.current = '';
              }

              if (currentOutputTranscriptionRef.current.trim()) {
                const text = currentOutputTranscriptionRef.current;
                setMessages(prev => [...prev, {
                  id: Date.now().toString() + '-agent',
                  role: 'agent',
                  text: text
                }]);
                currentOutputTranscriptionRef.current = '';
              }
            }

            const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio) {
              // Ensure audio context is running (browser autoplay policy might have suspended it)
              if (ctx.state === 'suspended') {
                 try { await ctx.resume(); } catch(e) { console.warn("Audio Context resume failed", e); }
              }

              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              const audioBuffer = await decodeAudioData(
                base64ToUint8Array(base64Audio),
                ctx,
                24000,
                1
              );
              const source = ctx.createBufferSource();
              source.buffer = audioBuffer;
              if (outputAnalyserRef.current) source.connect(outputAnalyserRef.current);
              else source.connect(ctx.destination);
              
              source.addEventListener('ended', () => activeSourcesRef.current.delete(source));
              source.start(nextStartTimeRef.current);
              activeSourcesRef.current.add(source);
              nextStartTimeRef.current += audioBuffer.duration;
            }

            if (message.serverContent?.interrupted) {
              activeSourcesRef.current.forEach(src => { try { src.stop(); } catch(e) {} });
              activeSourcesRef.current.clear();
              nextStartTimeRef.current = 0;
              currentOutputTranscriptionRef.current = '';
              currentInputTranscriptionRef.current = '';
            }
          },
          onclose: () => {
            console.log("Connection closed");
            if (state === 'connected') {
                setState('disconnected');
            }
            isConnectingRef.current = false;
          },
          onerror: (err: any) => {
            // Auto-retry logic for service unavailable OR network error
            const errorMsg = (err.message || (err.toString ? err.toString() : 'unknown error')).toLowerCase();
            const isUnavailable = errorMsg.includes('unavailable') || errorMsg.includes('503') || errorMsg.includes('service unavailable');
            const isNetworkError = errorMsg.includes('network error') || errorMsg.includes('failed to fetch') || errorMsg.includes('networkerror');
            
            const MAX_RETRIES = 3;

            if ((isUnavailable || isNetworkError) && reconnectAttemptsRef.current < MAX_RETRIES) {
                // If the primary model fails, switch to fallback model if applicable (already on exp, but safe to keep logic)
                if (currentModelRef.current === 'gemini-2.5-flash-native-audio-preview-09-2025') {
                    console.warn("Primary model unstable (Network/503), switching to fallback: gemini-2.0-flash-exp");
                    currentModelRef.current = 'gemini-2.0-flash-exp';
                }

                const nextDelay = 1500 * (reconnectAttemptsRef.current + 1);
                console.warn(`Connection Error (${errorMsg}). Retrying in ${nextDelay}ms... (Attempt ${reconnectAttemptsRef.current + 1}/${MAX_RETRIES})`);
                
                reconnectAttemptsRef.current++;
                isConnectingRef.current = false; // Release lock for retry
                
                retryTimeoutRef.current = setTimeout(() => {
                    connect(userLang);
                }, nextDelay);
            } else {
                console.error('Gemini Live API Fatal Error:', err);
                setState('error');
                isConnectingRef.current = false;
                reconnectAttemptsRef.current = 0;
            }
          }
        }
      });

    } catch (error) {
      console.error('Connection failed (try/catch):', error);
      setState('error');
      isConnectingRef.current = false;
    }
  }, [state]);

  const sendText = useCallback((text: string) => {
    resumeAudio(); // Ensure context is running when sending text
    if (state === 'connected' && sessionPromiseRef.current) {
      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        role: 'user',
        text: text
      }]);

      sessionPromiseRef.current.then(session => {
        session.sendRealtimeInput({
            clientContent: {
                turns: [{
                  role: 'user',
                  parts: [{ text: text }]
                }],
                turnComplete: true
            }
        });
      });
    }
  }, [state, resumeAudio]);

  const generateVideo = useCallback(async (file: File, prompt: string = "Cinematic slow motion animation") => {
    resumeAudio();
    const apiKey = process.env.API_KEY;
    if (!apiKey) return;
    
    // Add temporary messages
    const loadingId = Date.now().toString() + '-loading';
    setMessages(prev => [...prev, {
        id: Date.now().toString() + '-upload',
        role: 'user',
        text: `[Image Uploaded] Generating video: "${prompt}"`
    }]);

    setMessages(prev => [...prev, {
        id: loadingId,
        role: 'agent',
        text: "Generating your video with Veo (AI), this may take a few moments..."
    }]);

    try {
        const ai = new GoogleGenAI({ apiKey });
        const reader = new FileReader();
        reader.readAsDataURL(file);

        reader.onloadend = async () => {
            const base64Data = (reader.result as string).split(',')[1];
            
            try {
                let operation = await ai.models.generateVideos({
                    model: 'veo-3.1-fast-generate-preview',
                    prompt: prompt,
                    image: {
                        imageBytes: base64Data,
                        mimeType: file.type,
                    },
                    config: {
                        numberOfVideos: 1,
                        resolution: '720p',
                        aspectRatio: '16:9'
                    }
                });

                while (!operation.done) {
                    await new Promise(resolve => setTimeout(resolve, 5000));
                    operation = await ai.operations.getVideosOperation({ operation: operation });
                }

                if (operation.response?.generatedVideos?.[0]?.video?.uri) {
                    const videoUri = operation.response.generatedVideos[0].video.uri;
                    const response = await fetch(`${videoUri}&key=${apiKey}`);
                    const blob = await response.blob();
                    const videoUrl = URL.createObjectURL(blob);

                    setMessages(prev => prev.map(msg => 
                        msg.id === loadingId 
                        ? { ...msg, text: "Here is your Veo animation:", videoUrl: videoUrl } 
                        : msg
                    ));
                }
            } catch (err) {
                console.error("Veo Error:", err);
                setMessages(prev => prev.map(msg => 
                    msg.id === loadingId 
                    ? { ...msg, text: "Sorry, video generation failed. Please try again." } 
                    : msg
                ));
            }
        };
    } catch (e) {
        console.error(e);
    }
  }, [resumeAudio]);

  const generateImage = useCallback(async (prompt: string, size: '1K' | '2K' | '4K' = '1K') => {
    resumeAudio();
    const apiKey = process.env.API_KEY;
    if (!apiKey) return;
    
    // UI Feedback
    const loadingId = Date.now().toString() + '-loading-img';
    setMessages(prev => [...prev, {
        id: Date.now().toString() + '-req-img',
        role: 'user',
        text: `[Image Request] "${prompt}" (${size})`
    }]);

    setMessages(prev => [...prev, {
        id: loadingId,
        role: 'agent',
        text: "Generating image with Gemini 3 Pro..."
    }]);

    try {
        const ai = new GoogleGenAI({ apiKey });
        const response = await ai.models.generateContent({
            model: 'gemini-3-pro-image-preview',
            contents: {
                parts: [{ text: prompt }]
            },
            config: {
                imageConfig: {
                    imageSize: size,
                    aspectRatio: "16:9" // Default to landscape
                }
            }
        });

        let imageUrl = '';
        const parts = response.candidates?.[0]?.content?.parts || [];
        for (const part of parts) {
            if (part.inlineData && part.inlineData.mimeType.startsWith('image')) {
                imageUrl = `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
                break;
            }
        }

        if (imageUrl) {
             setMessages(prev => prev.map(msg => 
                msg.id === loadingId 
                ? { ...msg, text: "Here is your generated image:", imageUrl: imageUrl } 
                : msg
            ));
        } else {
             setMessages(prev => prev.map(msg => 
                msg.id === loadingId 
                ? { ...msg, text: "Generation complete but no image data found." } 
                : msg
            ));
        }

    } catch (e: any) {
        console.error("Image Gen Error:", e);
        setMessages(prev => prev.map(msg => 
            msg.id === loadingId 
            ? { ...msg, text: `Sorry, image generation failed. ${e.message || ''}` } 
            : msg
        ));
    }
  }, [resumeAudio]);

  const disconnect = useCallback(() => {
    isConnectingRef.current = false; // Reset lock
    reconnectAttemptsRef.current = 0; // Reset retries
    if (retryTimeoutRef.current) clearTimeout(retryTimeoutRef.current);
    
    setIsMuted(false);
    isMutedRef.current = false;
    currentModelRef.current = 'gemini-2.0-flash-exp'; // Reset model preference to stable

    sessionPromiseRef.current?.then(session => {
       // session.close() usually handled by context
    });
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (sourceNodeRef.current) sourceNodeRef.current.disconnect();
    if (processorRef.current) {
      processorRef.current.disconnect();
      processorRef.current.onaudioprocess = null;
    }
    if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    
    setVolume(0);
    setIsSpeaking(false);
    setState('disconnected');
    setMessages([]);
    currentOutputTranscriptionRef.current = '';
    currentInputTranscriptionRef.current = '';
    setAgentName(null);
  }, []);

  useEffect(() => {
    return () => {
      disconnect();
      if (inputAudioContextRef.current) inputAudioContextRef.current.close();
      if (outputAudioContextRef.current) outputAudioContextRef.current.close();
    };
  }, [disconnect]);

  return { state, connect, disconnect, sendText, generateVideo, generateImage, toggleMute, isMuted, isSpeaking, volume, messages, agentName, hasMicAccess, resumeAudio };
};

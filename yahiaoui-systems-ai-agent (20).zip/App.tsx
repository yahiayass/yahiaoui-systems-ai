
import React, { useState, useRef, useEffect } from 'react';
import { useLiveAgent } from './hooks/useLiveAgent';
import { Visualizer } from './components/Visualizer';
import { Header } from './components/Header';
import { NeuralBackground } from './components/NeuralBackground';

// Custom Select Component for Tech UI
interface Option {
    value: string;
    label: string;
}

const CustomSelect: React.FC<{
    label: string;
    options: Option[];
    value: string;
    onChange: (value: string) => void;
    placeholder?: string;
}> = ({ label, options, value, onChange, placeholder = "..." }) => {
    const [isOpen, setIsOpen] = useState(false);
    const containerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const selectedLabel = options.find(o => o.value === value)?.label;

    return (
        <div className="space-y-2 relative" ref={containerRef}>
            <label className="text-xs font-bold text-neutral-500 uppercase tracking-widest">{label}</label>
            <div 
                onClick={() => setIsOpen(!isOpen)}
                className={`w-full bg-black border ${isOpen ? 'border-brand-500 shadow-[0_0_15px_rgba(239,68,68,0.2)]' : 'border-neutral-700 hover:border-neutral-500'} text-white px-4 py-3 cursor-pointer flex justify-between items-center transition-all duration-300 relative z-20`}
            >
                <span className={`font-medium ${value ? 'text-white' : 'text-neutral-600'}`}>
                    {selectedLabel || placeholder}
                </span>
                <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    width="16" 
                    height="16" 
                    viewBox="0 0 24 24" 
                    fill="none" 
                    stroke="currentColor" 
                    strokeWidth="2" 
                    strokeLinecap="round" 
                    strokeLinejoin="round"
                    className={`text-neutral-500 transition-transform duration-300 ${isOpen ? 'rotate-180 text-brand-500' : ''}`}
                >
                    <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
            </div>
            
            {/* Dropdown Menu */}
            <div className={`
                absolute left-0 right-0 top-[calc(100%+4px)] bg-black border border-neutral-800 shadow-2xl z-50
                transition-all duration-300 origin-top max-h-80 overflow-y-auto scrollbar-thin scrollbar-thumb-brand-900 scrollbar-track-neutral-900
                ${isOpen ? 'opacity-100 scale-y-100 visible' : 'opacity-0 scale-y-95 invisible'}
            `}>
                <div>
                    {options.map((opt) => (
                        <div 
                            key={opt.value}
                            onClick={() => { onChange(opt.value); setIsOpen(false); }}
                            className={`
                                px-4 py-3 cursor-pointer text-sm font-bold uppercase tracking-wide border-l-2 border-transparent transition-all duration-200
                                ${value === opt.value ? 'bg-neutral-900 text-brand-500 border-brand-500' : 'text-neutral-400 hover:bg-brand-600 hover:text-white hover:border-white hover:pl-6'}
                            `}
                        >
                            {opt.label}
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

// Component for Reveal on Scroll animation
const RevealOnScroll: React.FC<{ children: React.ReactNode, className?: string }> = ({ children, className = "" }) => {
    const ref = useRef<HTMLDivElement>(null);
    const [isVisible, setIsVisible] = useState(false);

    useEffect(() => {
        const observer = new IntersectionObserver(([entry]) => {
            if (entry.isIntersecting) {
                setIsVisible(true);
                observer.unobserve(entry.target);
            }
        }, { threshold: 0.1 });

        if (ref.current) observer.observe(ref.current);

        return () => observer.disconnect();
    }, []);

    return (
        <div ref={ref} className={`transition-all duration-1000 transform ${isVisible ? 'opacity-100 translate-y-0 blur-none' : 'opacity-0 translate-y-10 blur-sm'} ${className}`}>
            {children}
        </div>
    );
};

// Project Data Type
interface ProjectData {
    title: string;
    cat: string;
    clientName: string;
    description: string;
    techStack: string[];
    results: string[];
    imageUrl: string; 
    categoryKey: string;
}

// Translations Dictionary
const TRANSLATIONS = {
    fr: {
        hero: {
            agency: "Agence d'Automatisation & Web",
            titleLine1: "DIGITALISEZ",
            titleLine2: "VOTRE VISION.",
            subtitleStart: "Yahiaoui Systems combine",
            subtitleDesign: "Design Futuriste",
            subtitleAnd: "et",
            subtitleAI: "Intelligence Artificielle",
            subtitleEnd: "pour créer des écosystèmes digitaux qui travaillent pour vous.",
            ctaStart: "Lancer mon Projet",
            ctaProjects: "Voir nos Réalisations"
        },
        stack: {
            title: "Technologies Maîtrisées"
        },
        about: {
            cardTitle: "Plus qu'une agence, <br/>un partenaire de croissance.",
            cardText: "Chez Yahiaoui Systems, nous ne livrons pas juste du code. Nous livrons de la valeur. Notre approche repose sur l'automatisation intelligente : pourquoi faire manuellement ce que l'IA peut faire instantanément ?",
            statCustom: "Sur-mesure",
            statAuto: "Automatisation",
            sectionTitle: "À Propos",
            mainTitle: "L'Expertise Freelance <br/>au service de votre ambition.",
            description: "Je suis développeur expert en solutions digitales. Mon objectif est simple : vous faire gagner du temps et de l'argent grâce à des sites web performants et des workflows automatisés.",
            bullets: ['Audit complet de vos processus', 'Développement agile et transparent', 'Formation et suivi post-livraison']
        },
        services: {
            sectionTitle: "Nos Services",
            mainTitle: "Solutions Digitales",
            web: {
                title: "Création Web",
                desc: "Sites vitrines et E-commerce ultra-rapides, optimisés pour la conversion et le mobile.",
                list: ["• Landing Pages", "• Boutiques Shopify / Woocommerce", "• Applications SaaS"]
            },
            auto: {
                title: "Automatisation IA",
                tag: "Populaire",
                desc: "Connectez vos outils (CRM, Email, Sheets) pour automatiser les tâches répétitives.",
                list: ["• Scénarios n8n / Make", "• Chatbots IA Custom", "• Génération de Leads"]
            },
            design: {
                title: "Design & Branding",
                desc: "Une identité visuelle forte pour vous démarquer de la concurrence.",
                list: ["• UI / UX Design", "• Refonte Graphique", "• Logos & Charters"]
            }
        },
        projects: {
            title: "Réalisations",
            subtitle: "Récents",
            modal: {
                client: "Client",
                stack: "Tech Stack",
                results: "Résultats",
                cta: "Demander un projet similaire"
            },
            items: [
                {
                    title: "E-Commerce Luxe",
                    cat: "Site Web & SEO",
                    description: "Refonte complète de l'expérience d'achat pour une maison de haute joaillerie. Migration vers une architecture Headless pour une vitesse instantanée et des animations fluides.",
                    results: ["+40% Taux de conversion", "-1.2s Temps de chargement", "+25% Panier moyen"]
                },
                {
                    title: "CRM Immobilier",
                    cat: "Automatisation n8n",
                    description: "Système d'automatisation connectant les leads entrants (Web, Facebook Ads) directement aux agents via WhatsApp et CRM, avec qualification automatique par IA.",
                    results: ["15h gagnées/semaine par agent", "Réponse aux leads < 1min", "Qualification automatique"]
                },
                {
                    title: "Agent Support IA",
                    cat: "Intelligence Artificielle",
                    description: "Déploiement d'un agent conversationnel entraîné sur la base de connaissances de l'entreprise. Capable de résoudre 70% des tickets de niveau 1 sans intervention humaine.",
                    results: ["-70% Tickets Support", "Disponibilité 24/7", "Satisfaction client 4.8/5"]
                },
                {
                    title: "Dashboard SaaS",
                    cat: "React & Next.js",
                    description: "Interface d'administration financière complexe avec visualisation de données en temps réel. Design système complet et optimisation des performances de rendu.",
                    results: ["10k Utilisateurs actifs", "Rendu temps réel < 50ms", "Mode Sombre/Clair"]
                }
            ]
        },
        pricing: {
            title: "Tarifs",
            subtitle: "Transparents",
            unit: "/PROJET",
            starter: {
                name: "Starter",
                items: ["✓ Site Vitrine One-Page", "✓ Design Responsive", "✓ Formulaire de Contact"],
                cta: "Commander"
            },
            business: {
                name: "Business",
                tag: "Best Seller",
                items: ["✓ Site Complet (5 pages)", "✓ Optimisation SEO", "✓ Blog / Actu", "✓ Module Chatbot Basic"],
                cta: "Commander"
            },
            auto: {
                name: "Automation",
                price: "Sur Devis",
                items: ["✓ Workflows n8n Complexes", "✓ Agents IA Personnalisés", "✓ Intégration API"],
                cta: "Me Contacter"
            }
        },
        contact: {
            title: "Prêt à",
            subtitle: "décoller",
            qmark: "?",
            desc: "Chaque grand projet commence par une simple discussion. Parlez-moi de vos ambitions, je m'occupe de la technologie.",
            email: "Email Direct",
            formTitle: "Formulaire de Contact",
            successTitle: "Message Reçu !",
            successDesc: "Je reviens vers vous très vite.",
            labels: {
                name: "Nom",
                email: "Email",
                type: "Type de projet",
                budget: "Estimated Budget",
                precision: "Précision (Optionnel)",
                message: "Message"
            },
            placeholders: {
                name: "Votre Nom",
                email: "votre@email.com",
                precision: "Ex: Environ 12 000 €",
                message: "Décrivez votre projet..."
            },
            btn: "Envoyer le Message",
            sending: "Envoi..."
        },
        chat: {
            online: "En ligne",
            connecting: "Connexion...",
            offline: "Hors ligne",
            error: "Erreur (Cliquer pour réessayer)",
            placeholder: "Écrivez un message...",
            placeholderNoMic: "Micro désactivé, écrivez...",
            connectPlaceholder: "Connectez l'agent d'abord",
            empty: "Je suis à votre écoute.",
            genVideo: "Générer une vidéo (Veo)",
            genImage: "Générer une image (Gemini 3)"
        },
        legal: {
            title: "Mentions Légales",
            content: [
                {
                    title: "1. Éditeur du site",
                    text: "Le site Yahiaoui Systems est édité par l'agence Yahiaoui Systems.\nContact : yahiayasscontat@gmail.com"
                },
                {
                    title: "2. Hébergement",
                    text: "Ce site est hébergé par Cloudflare, Inc.\nSiège social : 101 Townsend St, San Francisco, CA 94107, USA.\nSite web : https://www.cloudflare.com"
                },
                {
                    title: "3. Propriété Intellectuelle",
                    text: "L'ensemble de ce site relève de la législation française et internationale sur le droit d'auteur et la propriété intellectuelle. Tous les droits de reproduction sont réservés, y compris pour les documents téléchargeables et les représentations iconographiques et photographiques."
                },
                {
                    title: "4. Données Personnelles",
                    text: "Conformément au RGPD, vous disposez d'un droit d'accès, de rectification et de suppression des données vous concernant. Pour exercer ce droit, contactez-nous par email. Aucune donnée personnelle n'est vendue à des tiers."
                }
            ]
        },
        cgv: {
            title: "Conditions Générales de Vente (CGV)",
            content: [
                {
                    title: "1. Objet et Champ d'application",
                    text: "Les présentes conditions générales de vente régissent la vente de services de création web, d'automatisation et de design par Yahiaoui Systems. Toute commande implique l'acceptation sans réserve des présentes CGV par le client."
                },
                {
                    title: "2. Commandes et Devis",
                    text: "Les prestations font l'objet d'un devis préalable. La commande ne devient définitive qu'après signature du devis et réception de l'acompte prévu. Yahiaoui Systems se réserve le droit de refuser toute commande."
                },
                {
                    title: "3. Pricing and Payment",
                    text: "Les prix sont stipulés en euros. Un acompte de 40% est exigé à la commande, le solde étant dû à la livraison. En cas de retard de paiement, des pénalités seront appliquées conformément à la loi en vigueur."
                },
                {
                    title: "4. Delivery and Deadlines",
                    text: "Les délais de livraison sont donnés à titre indicatif. Un retard ne peut donner lieu à dommages et intérêts ou annulation de la commande que s'il est avéré et imputable exclusivement à Yahiaoui Systems."
                },
                {
                    title: "5. Propriété Intellectuelle",
                    text: "Le transfert de propriété des réalisations (site web, visuels, code) est subordonné au paiement intégral du prix. Yahiaoui Systems conserve la propriété intellectuelle sur ses méthodes et savoir-faire."
                },
                {
                    title: "6. Responsabilité",
                    text: "Yahiaoui Systems est tenu à une obligation de moyens. Sa responsabilité ne saurait être engagée pour des dommages indirects, pertes de données ou manques à gagner subis par le client."
                }
            ]
        }
    },
    en: {
        hero: {
            agency: "Automation & Web Agency",
            titleLine1: "DIGITIZE",
            titleLine2: "YOUR VISION.",
            subtitleStart: "Yahiaoui Systems combines",
            subtitleDesign: "Futuristic Design",
            subtitleAnd: "and",
            subtitleAI: "Artificial Intelligence",
            subtitleEnd: "to create digital ecosystems that work for you.",
            ctaStart: "Start Project",
            ctaProjects: "View Work"
        },
        stack: {
            title: "Mastered Technologies"
        },
        about: {
            cardTitle: "More than an agency, <br/>a growth partner.",
            cardText: "At Yahiaoui Systems, we don't just deliver code. We deliver value. Our approach relies on intelligent automation: why do manually what AI can do instantly?",
            statCustom: "Tailor-made",
            statAuto: "Automation",
            sectionTitle: "About",
            mainTitle: "Freelance Expertise <br/>at the service of your ambition.",
            description: "I am an expert developer in digital solutions. My goal is simple: save you time and money through high-performance websites and automated workflows.",
            bullets: ['Complete audit of your processes', 'Agile and transparent development', 'Training and post-delivery follow-up']
        },
        services: {
            sectionTitle: "Our Services",
            mainTitle: "Digital Solutions",
            web: {
                title: "Web Creation",
                desc: "Ultra-fast showcase and E-commerce sites, optimized for conversion and mobile.",
                list: ["• Landing Pages", "• Shopify / Woocommerce Stores", "• SaaS Applications"]
            },
            auto: {
                title: "AI Automation",
                tag: "Popular",
                desc: "Connect your tools (CRM, Email, Sheets) to automate repetitive tasks.",
                list: ["• n8n / Make Scenarios", "• Custom AI Chatbots", "• Lead Generation"]
            },
            design: {
                title: "Design & Branding",
                desc: "A strong visual identity to stand out from the competition.",
                list: ["• UI / UX Design", "• Graphic Redesign", "• Logos & Charters"]
            }
        },
        projects: {
            title: "Portfolio",
            subtitle: "Recent",
            modal: {
                client: "Client",
                stack: "Tech Stack",
                results: "Results",
                cta: "Request similar project"
            },
            items: [
                {
                    title: "Luxury E-Commerce",
                    cat: "Web Site & SEO",
                    description: "Complete redesign of the shopping experience for a high jewelry house. Migration to a Headless architecture for instant speed and fluid animations.",
                    results: ["+40% Conversion Rate", "-1.2s Load Time", "+25% Average Cart"]
                },
                {
                    title: "Real Estate CRM",
                    cat: "n8n Automation",
                    description: "Automation system connecting incoming leads (Web, Facebook Ads) directly to agents via WhatsApp and CRM, with automatic qualification by AI.",
                    results: ["15h saved/week per agent", "Lead response < 1min", "Automatic Qualification"]
                },
                {
                    title: "AI Support Agent",
                    cat: "Artificial Intelligence",
                    description: "Deployment of a conversational agent trained on the company's knowledge base. Capable of resolving 70% of Level 1 tickets without human intervention.",
                    results: ["-70% Support Tickets", "24/7 Availability", "Customer Satisfaction 4.8/5"]
                },
                {
                    title: "SaaS Dashboard",
                    cat: "React & Next.js",
                    description: "Complex financial administration interface with real-time data visualization. Complete design system and rendering performance optimization.",
                    results: ["10k Active Users", "Real-time render < 50ms", "Dark/Light Mode"]
                }
            ]
        },
        pricing: {
            title: "Pricing",
            subtitle: "Transparent",
            unit: "/PROJECT",
            starter: {
                name: "Starter",
                items: ["✓ One-Page Showcase", "✓ Responsive Design", "✓ Contact Form"],
                cta: "Order"
            },
            business: {
                name: "Business",
                tag: "Best Seller",
                items: ["✓ Complete Site (5 pages)", "✓ SEO Optimization", "✓ Blog / News", "✓ Basic Chatbot Module"],
                cta: "Order"
            },
            auto: {
                name: "Automation",
                price: "Custom Quote",
                items: ["✓ Complex n8n Workflows", "✓ Custom AI Agents", "✓ API Integration"],
                cta: "Contact Me"
            }
        },
        contact: {
            title: "Ready to",
            subtitle: "take off",
            qmark: "?",
            desc: "Every great project starts with a simple discussion. Tell me about your ambitions, I'll handle the technology.",
            email: "Direct Email",
            formTitle: "Quick Form",
            successTitle: "Message Received!",
            successDesc: "I'll get back to you very quickly.",
            labels: {
                name: "Name",
                email: "Email",
                type: "Project Type",
                budget: "Estimated Budget",
                precision: "Precision (Optional)",
                message: "Message"
            },
            placeholders: {
                name: "Your Name",
                email: "your@email.com",
                precision: "Ex: Around €12,000",
                message: "Describe your project..."
            },
            btn: "Send Message",
            sending: "Sending..."
        },
        chat: {
            online: "Online",
            connecting: "Connecting...",
            offline: "Offline",
            error: "Error (Click to retry)",
            placeholder: "Type a message...",
            placeholderNoMic: "Mic disabled, type...",
            connectPlaceholder: "Connect agent first",
            empty: "I am listening.",
            genVideo: "Generate video (Veo)",
            genImage: "Generate image (Gemini 3)"
        },
        legal: {
            title: "Legal Notice",
            content: [
                {
                    title: "1. Site Editor",
                    text: "The Yahiaoui Systems website is published by the Yahiaoui Systems agency.\nContact: yahiayasscontat@gmail.com"
                },
                {
                    title: "2. Hosting",
                    text: "This site is hosted by Cloudflare, Inc.\nHeadquarters: 101 Townsend St, San Francisco, CA 94107, USA.\nWebsite: https://www.cloudflare.com"
                },
                {
                    title: "3. Intellectual Property",
                    text: "This entire site is subject to French and international legislation on copyright and intellectual property. All reproduction rights are reserved."
                },
                {
                    title: "4. Personal Data",
                    text: "In accordance with GDPR, you have the right to access, rectify, and delete data concerning you. To exercise this right, contact us via email. No personal data is sold to third parties."
                }
            ]
        },
        cgv: {
            title: "Terms and Conditions of Sale (CGV)",
            content: [
                {
                    title: "1. Object and Scope",
                    text: "These general terms and conditions of sale govern the sale of web creation, automation, and design services by Yahiaoui Systems. Any order implies unreserved acceptance of these GTC by the client."
                },
                {
                    title: "2. Orders and Quotes",
                    text: "Services are subject to a prior quote. The order becomes final only after signature of the quote and receipt of the expected deposit. Yahiaoui Systems reserves the right to refuse any order."
                },
                {
                    title: "3. Pricing and Payment",
                    text: "Prices are stipulated in Euros. A 40% deposit is required upon ordering, the balance being due upon delivery. In case of late payment, penalties will be applied in accordance with current law."
                },
                {
                    title: "4. Delivery and Deadlines",
                    text: "Delivery times are given for information only. A delay cannot give rise to damages or cancellation of the order unless it is proven and attributable exclusively to Yahiaoui Systems."
                },
                {
                    title: "5. Intellectual Property",
                    text: "The transfer of ownership of the achievements (website, visuals, code) is subject to full payment of the price. Yahiaoui Systems retains intellectual property over its methods and know-how."
                },
                {
                    title: "6. Liability",
                    text: "Yahiaoui Systems is bound by an obligation of means. Its liability cannot be engaged for indirect damages, data loss, or loss of profit suffered by the client."
                }
            ]
        }
    }
};

const App: React.FC = () => {
  const [lang, setLang] = useState<'fr' | 'en'>('fr');
  const t = TRANSLATIONS[lang]; // Shortcut for current language translations

  const { state, connect, disconnect, sendText, generateVideo, generateImage, toggleMute, isMuted, isSpeaking, volume, messages, agentName, hasMicAccess, resumeAudio } = useLiveAgent();
  const [isOpen, setIsOpen] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Image Gen UI State
  const [showImagePanel, setShowImagePanel] = useState(false);
  const [imageSize, setImageSize] = useState<'1K' | '2K' | '4K'>('1K');

  const [selectedProject, setSelectedProject] = useState<ProjectData | null>(null);
  const [isLegalOpen, setIsLegalOpen] = useState(false);
  const [isCGVOpen, setIsCGVOpen] = useState(false);

  const [contactForm, setContactForm] = useState({ 
    name: '', 
    email: '', 
    projectType: '',
    budget: '',
    customBudget: '',
    message: '' 
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSent, setIsSent] = useState(false);

  // AUTO CONNECT ON MOUNT
  useEffect(() => {
     // Connecter l'agent dès le chargement du site
     if (state === 'disconnected') {
        // Small delay to ensure browser is ready and to prevent immediate React double-mount issues in some cases
        const timer = setTimeout(() => {
            connect(lang);
        }, 1000);
        return () => clearTimeout(timer);
     }
  }, []); 

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
        setIsSubmitting(false);
        setIsSent(true);
        setContactForm({ name: '', email: '', message: '', projectType: '', budget: '', customBudget: '' });
        setTimeout(() => setIsSent(false), 5000);
    }, 1500);
  };

  const prefillAndScrollToContact = (type: string, budget: string, messagePrefix: string) => {
    setContactForm(prev => ({
        ...prev,
        projectType: type,
        budget: budget,
        message: messagePrefix
    }));
    
    const element = document.getElementById('contact');
    if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleReconnect = () => {
      disconnect();
      setTimeout(() => connect(lang), 500);
  };

  // Safe Resume Audio wrapper
  const handleInteraction = () => {
     if (state === 'connected') {
        resumeAudio();
     }
  };

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isOpen]);

  const toggleWidget = () => {
    handleInteraction(); // Important: Resume audio context on click
    if (isOpen) {
      setIsOpen(false);
    } else {
      setIsOpen(true);
      if (state === 'disconnected' || state === 'error') {
        connect(lang);
      }
    }
  };

  const handleSend = (e?: React.FormEvent) => {
    e?.preventDefault();
    handleInteraction(); // Resume audio context
    if (inputValue.trim() && state === 'connected') {
      sendText(inputValue.trim());
      setInputValue('');
      setShowImagePanel(false); // Close image panel if open
    }
  };

  const handleImageGen = () => {
    handleInteraction();
    if (inputValue.trim() && state === 'connected') {
        generateImage(inputValue.trim(), imageSize);
        setInputValue('');
        setShowImagePanel(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    handleInteraction();
    const file = e.target.files?.[0];
    if (file && state === 'connected') {
        const prompt = inputValue.trim() || "Animate this image in cinematic style";
        generateVideo(file, prompt);
        setInputValue(''); 
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const triggerFileUpload = () => {
    if (state !== 'connected') {
        alert(lang === 'fr' ? "Veuillez d'abord connecter l'agent." : "Please connect the agent first.");
        return;
    }
    fileInputRef.current?.click();
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // Reconstruct projects based on current language
  const projectsData: ProjectData[] = [
    { 
      ...t.projects.items[0],
      clientName: "MAISON AURUM",
      techStack: ["Shopify Plus", "React", "WebGL", "Klaviyo"],
      categoryKey: 'ecommerce',
      imageUrl: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?q=80&w=1600&auto=format&fit=crop" 
    },
    { 
      ...t.projects.items[1],
      clientName: "IMMOFLOW AUTOMATION",
      techStack: ["n8n", "Airtable", "OpenAI API", "Twilio"],
      categoryKey: 'automation',
      imageUrl: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=1600&auto=format&fit=crop"
    },
    { 
      ...t.projects.items[2],
      clientName: "NEXABOT 24/7",
      techStack: ["Python", "LangChain", "Pinecone", "GPT-4"],
      categoryKey: 'automation',
      imageUrl: "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?q=80&w=1600&auto=format&fit=crop"
    },
    { 
      ...t.projects.items[3],
      clientName: "FINTRACK PRO",
      techStack: ["Next.js", "D3.js", "Supabase", "Tailwind CSS"],
      categoryKey: 'saas',
      imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=1600&auto=format&fit=crop"
    }
  ];

  // Options for dropdowns based on lang
  const projectTypeOptions = [
     { value: 'vitrine', label: lang === 'fr' ? 'Site Vitrine' : 'Showcase Website' },
     { value: 'ecommerce', label: lang === 'fr' ? 'E-Commerce' : 'E-Commerce' },
     { value: 'automation', label: lang === 'fr' ? 'Automatisation IA' : 'AI Automation' },
     { value: 'saas', label: lang === 'fr' ? 'SaaS / Web App' : 'SaaS / Web App' },
     { value: 'audit', label: lang === 'fr' ? 'Audit / Conseil' : 'Audit / Consulting' },
  ];

  const budgetOptions = [
    { value: 'micro', label: lang === 'fr' ? 'Micro-tâche / Debug (< 500€)' : 'Micro-task / Debug (< €500)' },
    { value: 'vitrine', label: lang === 'fr' ? 'Site Vitrine (500€ - 2k€)' : 'Showcase Site (€500 - €2k)' },
    { value: 'ecommerce', label: lang === 'fr' ? 'E-commerce (2k€ - 5k€)' : 'E-commerce (€2k - €5k)' },
    { value: 'automation', label: lang === 'fr' ? 'Automatisation (2k€ - 5k€)' : 'Automation (€2k - €5k)' },
    { value: 'saas', label: lang === 'fr' ? 'SaaS / App (5k€ - 15k€)' : 'SaaS / App (€5k - €15k)' },
    { value: 'scale', label: lang === 'fr' ? 'Transformation (> 20k€)' : 'Transformation (> €20k)' },
    { value: 'maintenance', label: lang === 'fr' ? 'Maintenance Mensuelle' : 'Monthly Maintenance' },
    { value: 'custom', label: lang === 'fr' ? 'Je ne sais pas / À définir' : 'I don\'t know / TBD' }
  ];

  return (
    <div className="relative w-full min-h-screen overflow-x-hidden bg-black font-sans text-white selection:bg-brand-500 selection:text-white">
      
      <div className="fixed inset-0 opacity-[0.03] pointer-events-none z-50 mix-blend-overlay bg-[url('https://grainy-gradients.vercel.app/noise.svg')]"></div>

      <NeuralBackground state={state} isSpeaking={isSpeaking} />

      <Header lang={lang} setLang={setLang} />
      
      {/* HERO SECTION */}
      <section className="relative z-10 pt-32 pb-20 px-6 max-w-7xl mx-auto flex flex-col items-start justify-center min-h-[90vh]">
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 bg-brand-900/20 rounded-full blur-3xl pointer-events-none animate-pulse-slow"></div>
        <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-80 h-80 bg-neutral-800/20 rounded-full blur-3xl pointer-events-none"></div>

        <div className="space-y-8 max-w-4xl animate-fade-in">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-neutral-800 bg-neutral-900/50 backdrop-blur-sm">
            <span className="w-2 h-2 rounded-full bg-brand-500 animate-pulse"></span>
            <span className="text-xs font-black text-neutral-300 tracking-[0.2em] uppercase">{t.hero.agency}</span>
          </div>

          <h1 className="text-6xl md:text-8xl lg:text-9xl font-black tracking-tighter leading-[0.9] uppercase drop-shadow-2xl relative group">
            {t.hero.titleLine1} <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-600 via-white to-brand-600 bg-[length:200%_auto] animate-text-flow relative z-10">
              {t.hero.titleLine2}
            </span>
          </h1>

          <p className="text-lg md:text-2xl text-neutral-400 leading-relaxed max-w-2xl font-medium tracking-wide">
            {t.hero.subtitleStart} <strong className="text-white">{t.hero.subtitleDesign}</strong> {t.hero.subtitleAnd} <strong className="text-white">{t.hero.subtitleAI}</strong> {t.hero.subtitleEnd}
          </p>

          <div className="flex flex-wrap gap-4 pt-6">
            <button onClick={() => prefillAndScrollToContact('automation', 'custom', '')} className="px-10 py-5 bg-brand-600 hover:bg-brand-500 text-white rounded-none skew-x-[-10deg] font-black uppercase tracking-widest transition-all shadow-[0_10px_30px_-10px_rgba(239,68,68,0.5)] hover:shadow-[0_20px_40px_-10px_rgba(239,68,68,0.6)] hover:-translate-y-1 group">
              <span className="block skew-x-[10deg] group-hover:scale-105 transition-transform">{t.hero.ctaStart}</span>
            </button>
            <a href="#projects" className="px-10 py-5 bg-transparent border-2 border-neutral-700 hover:border-white text-white rounded-none skew-x-[-10deg] font-black uppercase tracking-widest transition-all hover:bg-white/5 group">
              <span className="block skew-x-[10deg] group-hover:scale-105 transition-transform">{t.hero.ctaProjects}</span>
            </a>
          </div>
        </div>
      </section>

      {/* STACK TECH SECTION */}
      <RevealOnScroll className="relative z-10 py-16 bg-neutral-950/80 border-y border-neutral-900 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-6">
           <p className="text-center text-neutral-500 text-sm font-black uppercase tracking-[0.3em] mb-10">{t.stack.title}</p>
           <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-8 items-center justify-center text-center opacity-60">
              {["React", "Next.js", "Python", "n8n", "OpenAI", "Stripe"].map((tech, i) => (
                  <div key={i} className="flex items-center justify-center gap-2 hover:opacity-100 hover:text-brand-500 transition-all duration-300 cursor-default grayscale hover:grayscale-0 transform hover:scale-110">
                      <span className="text-2xl font-black uppercase tracking-tighter">{tech}</span>
                  </div>
              ))}
           </div>
        </div>
      </RevealOnScroll>

      {/* ABOUT SECTION */}
      <section id="about" className="relative z-10 py-24 bg-black">
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-16 items-center">
            <RevealOnScroll className="relative group">
                <div className="absolute inset-0 bg-brand-600 blur-[100px] opacity-20 group-hover:opacity-30 transition-opacity duration-700 animate-pulse-slow"></div>
                <div className="relative bg-neutral-900/50 backdrop-blur-xl border border-neutral-800 p-8 rounded-none skew-x-[-2deg] hover:skew-x-0 transition-transform duration-500 shadow-2xl hover:border-brand-500/30">
                    <h3 className="text-3xl font-black mb-4 text-white uppercase tracking-tight" dangerouslySetInnerHTML={{ __html: t.about.cardTitle }}></h3>
                    <p className="text-neutral-400 mb-6 leading-relaxed font-medium">
                        {t.about.cardText}
                    </p>
                    <div className="flex gap-12 border-t border-neutral-800 pt-6">
                        <div>
                            <span className="block text-5xl font-black text-brand-500 tracking-tighter">100%</span>
                            <span className="text-xs uppercase tracking-[0.2em] text-neutral-500 font-bold">{t.about.statCustom}</span>
                        </div>
                        <div>
                            <span className="block text-5xl font-black text-brand-500 tracking-tighter">24/7</span>
                            <span className="text-xs uppercase tracking-[0.2em] text-neutral-500 font-bold">{t.about.statAuto}</span>
                        </div>
                    </div>
                </div>
            </RevealOnScroll>
            <RevealOnScroll>
                <h2 className="text-sm font-black text-brand-500 uppercase tracking-[0.3em] mb-2">{t.about.sectionTitle}</h2>
                <h3 className="text-4xl md:text-6xl font-black mb-6 uppercase tracking-tighter text-white" dangerouslySetInnerHTML={{ __html: t.about.mainTitle }}></h3>
                <p className="text-neutral-400 text-lg mb-8 font-medium">
                    {t.about.description}
                </p>
                <ul className="space-y-4">
                    {t.about.bullets.map((item: string, i: number) => (
                        <li key={i} className="flex items-center gap-3 text-white font-bold uppercase tracking-wide group">
                            <span className="flex items-center justify-center w-6 h-6 rounded-none skew-x-[-10deg] bg-brand-600 text-white shadow-[0_0_10px_rgba(239,68,68,0.5)] group-hover:bg-white group-hover:text-brand-600 transition-colors">
                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                            </span>
                            {item}
                        </li>
                    ))}
                </ul>
            </RevealOnScroll>
        </div>
      </section>

      {/* SERVICES SECTION */}
      <section id="services" className="relative z-10 py-32 bg-neutral-950 overflow-hidden">
        <div className="absolute inset-0 overflow-hidden opacity-10 pointer-events-none"></div>

        <div className="max-w-7xl mx-auto px-6 relative z-10">
            <RevealOnScroll className="text-center mb-20">
              <h2 className="text-sm font-black text-brand-500 uppercase tracking-[0.3em] mb-3">{t.services.sectionTitle}</h2>
              <h3 className="text-5xl md:text-7xl font-black mb-4 uppercase tracking-tighter text-white">{t.services.mainTitle} <span className="text-brand-600">360°</span></h3>
            </RevealOnScroll>

            <div className="grid md:grid-cols-3 gap-8">
               <RevealOnScroll className="p-10 bg-neutral-900/80 backdrop-blur-md border border-neutral-800 hover:border-brand-500 hover:bg-neutral-900 transition-all duration-300 group hover:-translate-y-2 rounded-none hover:shadow-[0_0_30px_rgba(220,38,38,0.2)]">
                  <div className="w-14 h-14 bg-neutral-800 flex items-center justify-center mb-8 group-hover:bg-brand-600 transition-colors text-white shadow-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>
                  </div>
                  <h4 className="text-2xl font-black mb-4 text-white uppercase tracking-tight">{t.services.web.title}</h4>
                  <p className="text-neutral-400 text-sm mb-6 font-medium">{t.services.web.desc}</p>
                  <ul className="text-sm text-neutral-500 space-y-3 font-bold uppercase tracking-wide">
                      {t.services.web.list.map((item: string, i: number) => <li key={i}>{item}</li>)}
                  </ul>
               </RevealOnScroll>

               <RevealOnScroll className="p-10 bg-neutral-900/80 backdrop-blur-md border border-brand-900 hover:border-brand-500 hover:bg-neutral-900 transition-all duration-300 group hover:-translate-y-2 rounded-none relative hover:shadow-[0_0_40px_rgba(220,38,38,0.3)]">
                  <div className="absolute top-0 right-0 bg-brand-600 text-white text-[10px] font-black px-4 py-1 uppercase tracking-widest">{t.services.auto.tag}</div>
                  <div className="w-14 h-14 bg-neutral-800 flex items-center justify-center mb-8 group-hover:bg-brand-600 transition-colors text-white shadow-lg">
                     <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2a10 10 0 1 0 10 10H12V2z"></path><path d="M12 2a10 10 0 0 1 10 10"></path><path d="M2 12h10"></path></svg>
                  </div>
                  <h4 className="text-2xl font-black mb-4 text-white uppercase tracking-tight">{t.services.auto.title}</h4>
                  <p className="text-neutral-400 text-sm mb-6 font-medium">{t.services.auto.desc}</p>
                  <ul className="text-sm text-neutral-500 space-y-3 font-bold uppercase tracking-wide">
                      {t.services.auto.list.map((item: string, i: number) => <li key={i}>{item}</li>)}
                  </ul>
               </RevealOnScroll>

               <RevealOnScroll className="p-10 bg-neutral-900/80 backdrop-blur-md border border-neutral-800 hover:border-brand-500 hover:bg-neutral-900 transition-all duration-300 group hover:-translate-y-2 rounded-none hover:shadow-[0_0_30px_rgba(220,38,38,0.2)]">
                  <div className="w-14 h-14 bg-neutral-800 flex items-center justify-center mb-8 group-hover:bg-brand-600 transition-colors text-white shadow-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 20h9"></path><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path></svg>
                  </div>
                  <h4 className="text-2xl font-black mb-4 text-white uppercase tracking-tight">{t.services.design.title}</h4>
                  <p className="text-neutral-400 text-sm mb-6 font-medium">{t.services.design.desc}</p>
                  <ul className="text-sm text-neutral-500 space-y-3 font-bold uppercase tracking-wide">
                      {t.services.design.list.map((item: string, i: number) => <li key={i}>{item}</li>)}
                  </ul>
               </RevealOnScroll>
            </div>
        </div>
      </section>

      {/* PROJECTS SECTION */}
      <section id="projects" className="relative z-10 py-32 bg-black overflow-hidden">
         <div className="absolute inset-0 opacity-20">
             <div className="absolute w-2 h-2 bg-brand-500 rounded-full top-1/4 left-1/4 animate-pulse-slow"></div>
             <div className="absolute w-1 h-1 bg-white rounded-full top-3/4 right-1/4 animate-pulse-slow"></div>
             <div className="absolute w-3 h-3 bg-brand-900 rounded-full top-1/2 left-1/2 animate-pulse-slow"></div>
         </div>

         <div className="max-w-7xl mx-auto px-6 relative z-10">
            <RevealOnScroll>
                <h2 className="text-5xl md:text-7xl font-black mb-16 text-center uppercase tracking-tighter">{t.projects.title} <span className="text-brand-600">{t.projects.subtitle}</span></h2>
            </RevealOnScroll>
            
            <div className="grid md:grid-cols-2 gap-10">
                {projectsData.map((project, i) => (
                    <RevealOnScroll key={i}>
                        <div 
                            onClick={() => setSelectedProject(project)}
                            className="group relative h-80 bg-neutral-900 border border-neutral-800 cursor-pointer overflow-hidden shadow-2xl hover:border-brand-500 transition-all duration-500"
                        >
                            <img 
                              src={project.imageUrl} 
                              alt={project.title} 
                              loading="lazy"
                              className="absolute inset-0 w-full h-full object-cover grayscale transition-all duration-700 group-hover:grayscale-0 group-hover:scale-110 opacity-70 group-hover:opacity-100" 
                            />
                            
                            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent group-hover:via-black/20 transition-all duration-500"></div>
                            
                            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 bg-brand-600 rounded-full flex items-center justify-center opacity-0 scale-0 group-hover:opacity-100 group-hover:scale-100 transition-all duration-300 z-20 shadow-[0_0_30px_#ef4444]">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className="text-white"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                            </div>

                            <div className="absolute bottom-0 left-0 p-8 z-10 w-full transform group-hover:-translate-y-2 transition-transform duration-500">
                                <span className="text-brand-500 text-xs font-black uppercase tracking-[0.2em] mb-2 block shadow-black drop-shadow-md">{project.cat}</span>
                                <h3 className="text-3xl font-black text-white uppercase tracking-tight drop-shadow-lg">{project.title}</h3>
                                <div className="h-1 w-0 bg-brand-500 mt-4 group-hover:w-full transition-all duration-700 ease-out"></div>
                            </div>
                        </div>
                    </RevealOnScroll>
                ))}
            </div>
         </div>
      </section>

      {/* PROJECT DETAILS MODAL */}
      {selectedProject && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/95 backdrop-blur-xl animate-fade-in overflow-y-auto">
            <div className="relative w-full max-w-4xl bg-neutral-900 border border-brand-500/50 shadow-[0_0_50px_rgba(239,68,68,0.3)] rounded-none overflow-hidden flex flex-col md:flex-row">
                <button 
                    onClick={() => setSelectedProject(null)}
                    className="absolute top-4 right-4 z-20 p-2 bg-black/50 hover:bg-brand-600 text-white rounded-full transition-colors"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                </button>

                <div className="w-full md:w-1/3 bg-black relative border-r border-neutral-800 min-h-[300px]">
                    <img 
                        src={selectedProject.imageUrl} 
                        alt={selectedProject.title} 
                        className="w-full h-full object-cover absolute inset-0 opacity-80" 
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-neutral-900 to-transparent"></div>
                    <div className="absolute bottom-6 left-6 z-10">
                        <h4 className="text-brand-500 font-black uppercase tracking-widest text-xs mb-1">{t.projects.modal.client}</h4>
                        <p className="text-white text-xl font-black uppercase tracking-tighter">{selectedProject.clientName}</p>
                    </div>
                </div>

                <div className="w-full md:w-2/3 p-8 md:p-12">
                    <span className="inline-block px-3 py-1 mb-4 bg-brand-900/30 border border-brand-500/30 text-brand-500 text-xs font-bold uppercase tracking-widest rounded-full">
                        {selectedProject.cat}
                    </span>
                    <h2 className="text-4xl font-black text-white uppercase tracking-tight mb-6">{selectedProject.title}</h2>
                    
                    <p className="text-neutral-400 leading-relaxed mb-8 font-medium border-l-2 border-brand-500 pl-4">
                        {selectedProject.description}
                    </p>

                    <div className="grid grid-cols-2 gap-8 mb-8">
                        <div>
                            <h4 className="text-white font-black uppercase tracking-widest text-sm mb-3">{t.projects.modal.stack}</h4>
                            <div className="flex flex-wrap gap-2">
                                {selectedProject.techStack.map((tech, i) => (
                                    <span key={i} className="text-xs font-bold text-neutral-400 bg-black px-2 py-1 border border-neutral-800 uppercase">{tech}</span>
                                ))}
                            </div>
                        </div>
                        <div>
                            <h4 className="text-white font-black uppercase tracking-widest text-sm mb-3">{t.projects.modal.results}</h4>
                            <ul className="space-y-1">
                                {selectedProject.results.map((res, i) => (
                                    <li key={i} className="text-sm font-bold text-brand-500 flex gap-2 items-center">
                                        <span className="w-1.5 h-1.5 bg-brand-500 rounded-full"></span>
                                        {res}
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </div>

                    <button 
                        onClick={() => {
                            setSelectedProject(null);
                            prefillAndScrollToContact(selectedProject.categoryKey, 'custom', lang === 'fr' 
                              ? `Je suis intéressé par un projet similaire à ${selectedProject.title}.`
                              : `I am interested in a project similar to ${selectedProject.title}.`
                            );
                        }} 
                        className="inline-flex items-center gap-2 px-8 py-4 bg-brand-600 hover:bg-brand-500 text-white font-black uppercase tracking-widest transition-all shadow-lg hover:shadow-brand-500/30"
                    >
                        {t.projects.modal.cta}
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
                    </button>
                </div>
            </div>
        </div>
      )}

      {/* LEGAL MODAL */}
      {isLegalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/95 backdrop-blur-xl animate-fade-in overflow-y-auto">
            <div className="relative w-full max-w-3xl bg-neutral-900 border border-neutral-800 p-8 md:p-12 shadow-2xl">
                <button 
                    onClick={() => setIsLegalOpen(false)}
                    className="absolute top-4 right-4 p-2 text-neutral-500 hover:text-white transition-colors"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                </button>
                <h2 className="text-3xl font-black text-white uppercase tracking-tight mb-8 border-b border-brand-500/30 pb-4">{t.legal.title}</h2>
                <div className="space-y-8 text-neutral-400">
                    {t.legal.content.map((section: any, i: number) => (
                        <div key={i}>
                            <h3 className="text-white font-bold uppercase tracking-wide mb-2">{section.title}</h3>
                            <p className="whitespace-pre-line leading-relaxed">{section.text}</p>
                        </div>
                    ))}
                </div>
            </div>
        </div>
      )}

      {/* CGV MODAL */}
      {isCGVOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/95 backdrop-blur-xl animate-fade-in overflow-y-auto">
            <div className="relative w-full max-w-3xl bg-neutral-900 border border-neutral-800 p-8 md:p-12 shadow-2xl">
                <button 
                    onClick={() => setIsCGVOpen(false)}
                    className="absolute top-4 right-4 p-2 text-neutral-500 hover:text-white transition-colors"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                </button>
                <h2 className="text-3xl font-black text-white uppercase tracking-tight mb-8 border-b border-brand-500/30 pb-4">{t.cgv.title}</h2>
                <div className="space-y-8 text-neutral-400">
                    {t.cgv.content.map((section: any, i: number) => (
                        <div key={i}>
                            <h3 className="text-white font-bold uppercase tracking-wide mb-2">{section.title}</h3>
                            <p className="whitespace-pre-line leading-relaxed">{section.text}</p>
                        </div>
                    ))}
                </div>
            </div>
        </div>
      )}

      {/* PRICING SECTION */}
      <section id="pricing" className="relative z-10 py-32 bg-neutral-950 overflow-hidden">
         <div className="absolute inset-0 bg-neutral-950">
             <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-brand-900/10 rounded-full blur-[120px] pointer-events-none animate-pulse-slow"></div>
         </div>

         <div className="max-w-7xl mx-auto px-6 relative z-10">
            <RevealOnScroll>
                <h2 className="text-5xl md:text-7xl font-black mb-20 text-center uppercase tracking-tighter text-white drop-shadow-lg">{t.pricing.title} <span className="text-brand-600">{t.pricing.subtitle}</span></h2>
            </RevealOnScroll>
            
            <div className="group/pricing grid md:grid-cols-3 gap-8 max-w-6xl mx-auto items-center perspective-1000">
                <RevealOnScroll className="relative p-10 rounded-none border border-neutral-800 bg-neutral-900/40 backdrop-blur-md flex flex-col transition-all duration-500 ease-out
                                group-hover/pricing:blur-[3px] group-hover/pricing:scale-95 group-hover/pricing:opacity-50
                                hover:!blur-none hover:!scale-110 hover:!opacity-100 hover:!z-20 hover:!bg-black hover:border-brand-500 hover:shadow-[0_0_50px_rgba(239,68,68,0.6)]">
                    <h3 className="text-2xl font-black text-white mb-2 uppercase tracking-tight">{t.pricing.starter.name}</h3>
                    <div className="text-4xl font-black text-brand-500 mb-8 tracking-tighter">600€<span className="text-sm text-neutral-500 font-bold ml-2 tracking-normal">{t.pricing.unit}</span></div>
                    <ul className="space-y-4 mb-8 flex-1">
                        {t.pricing.starter.items.map((item: string, i: number) => (
                             <li key={i} className="text-sm text-neutral-300 font-bold uppercase tracking-wide flex gap-2">{item}</li>
                        ))}
                    </ul>
                    <button 
                        onClick={() => prefillAndScrollToContact('vitrine', 'vitrine', lang === 'fr' 
                          ? 'Je souhaite commander le pack Starter (Site Vitrine).' 
                          : 'I would like to order the Starter Pack (Showcase Site).')}
                        className="block w-full text-center py-4 border-2 border-neutral-700 text-white hover:bg-white hover:text-black hover:border-white transition-all font-black uppercase tracking-widest"
                    >
                        {t.pricing.starter.cta}
                    </button>
                </RevealOnScroll>
                
                <RevealOnScroll className="relative p-10 rounded-none border-2 border-brand-800 bg-black/60 backdrop-blur-xl flex flex-col transition-all duration-500 ease-out shadow-2xl z-10
                                group-hover/pricing:blur-[3px] group-hover/pricing:scale-95 group-hover/pricing:opacity-50
                                hover:!blur-none hover:!scale-110 hover:!opacity-100 hover:!z-30 hover:!bg-black hover:border-brand-500 hover:shadow-[0_0_80px_rgba(239,68,68,0.8)] transform scale-105">
                    <div className="absolute top-0 right-0 bg-brand-600 text-white text-[10px] font-black px-4 py-1 uppercase tracking-widest">{t.pricing.business.tag}</div>
                    <h3 className="text-2xl font-black text-white mb-2 uppercase tracking-tight">{t.pricing.business.name}</h3>
                    <div className="text-4xl font-black text-brand-500 mb-8 tracking-tighter">1500€<span className="text-sm text-neutral-500 font-bold ml-2 tracking-normal">{t.pricing.unit}</span></div>
                    <ul className="space-y-4 mb-8 flex-1">
                        {t.pricing.business.items.map((item: string, i: number) => (
                             <li key={i} className="text-sm text-white font-bold uppercase tracking-wide flex gap-2">{item}</li>
                        ))}
                    </ul>
                    <button 
                        onClick={() => prefillAndScrollToContact('vitrine', 'vitrine', lang === 'fr'
                          ? 'Je souhaite commander le pack Business (Site Complet).'
                          : 'I would like to order the Business Pack (Complete Site).')}
                        className="block w-full text-center py-4 bg-brand-600 text-white hover:bg-brand-500 transition-all font-black uppercase tracking-widest shadow-[0_0_30px_rgba(220,38,38,0.5)]"
                    >
                        {t.pricing.business.cta}
                    </button>
                </RevealOnScroll>
                
                <RevealOnScroll className="relative p-10 rounded-none border border-neutral-800 bg-neutral-900/40 backdrop-blur-md flex flex-col transition-all duration-500 ease-out
                                group-hover/pricing:blur-[3px] group-hover/pricing:scale-95 group-hover/pricing:opacity-50
                                hover:!blur-none hover:!scale-110 hover:!opacity-100 hover:!z-20 hover:!bg-black hover:border-brand-500 hover:shadow-[0_0_50px_rgba(239,68,68,0.6)]">
                    <h3 className="text-2xl font-black text-white mb-2 uppercase tracking-tight">{t.pricing.auto.name}</h3>
                    <div className="text-4xl font-black text-brand-500 mb-8 tracking-tighter uppercase">{t.pricing.auto.price}</div>
                    <ul className="space-y-4 mb-8 flex-1">
                        {t.pricing.auto.items.map((item: string, i: number) => (
                             <li key={i} className="text-sm text-neutral-300 font-bold uppercase tracking-wide flex gap-2">{item}</li>
                        ))}
                    </ul>
                    <button 
                        onClick={() => prefillAndScrollToContact('automation', 'custom', lang === 'fr'
                          ? 'Je souhaite discuter d\'une solution d\'automatisation sur mesure.'
                          : 'I would like to discuss a custom automation solution.')}
                        className="block w-full text-center py-4 border-2 border-neutral-700 text-white hover:bg-white hover:text-black hover:border-white transition-all font-black uppercase tracking-widest"
                    >
                        {t.pricing.auto.cta}
                    </button>
                </RevealOnScroll>
            </div>
         </div>
      </section>

      {/* CONTACT SECTION */}
      <section id="contact" className="relative z-10 py-32 bg-black border-t border-neutral-900">
         <div className="absolute inset-0 overflow-hidden pointer-events-none">
             <div className="absolute inset-0 opacity-20">
                <div className="absolute top-1/2 left-1/2 w-[200vw] h-[200vh] -translate-x-1/2 -translate-y-1/2 bg-[conic-gradient(from_0deg,transparent_0deg,transparent_10deg,rgba(255,255,255,0.1)_15deg,transparent_20deg)] animate-[spin_10s_linear_infinite]"></div>
            </div>
         </div>

         <div className="max-w-7xl mx-auto px-6 relative z-10">
            <RevealOnScroll className="grid lg:grid-cols-2 gap-16 items-center">
                <div>
                    <h2 className="text-5xl md:text-7xl font-black mb-8 uppercase tracking-tighter">{t.contact.title} <span className="text-brand-600">{t.contact.subtitle}</span>{t.contact.qmark}</h2>
                    <p className="text-neutral-400 mb-10 text-xl font-medium leading-relaxed">
                        {t.contact.desc}
                    </p>
                    
                    <div className="space-y-6">
                         <div className="flex items-center gap-4 group cursor-pointer hover:translate-x-2 transition-transform">
                            <div className="w-12 h-12 bg-neutral-900 border border-neutral-800 flex items-center justify-center text-brand-500 group-hover:bg-brand-600 group-hover:text-white transition-all shadow-lg">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                            </div>
                            <div>
                                <h4 className="font-black text-white uppercase tracking-wide text-sm">{t.contact.email}</h4>
                                <a href="mailto:yahiayasscontat@gmail.com" className="text-neutral-400 hover:text-white transition-colors block">yahiayasscontat@gmail.com</a>
                            </div>
                         </div>
                    </div>
                </div>

                <div className="bg-neutral-900/50 backdrop-blur-xl border border-neutral-800 p-8 md:p-10 shadow-2xl relative group hover:border-brand-500/50 transition-colors">
                    <h3 className="text-2xl font-black text-white mb-6 uppercase tracking-tight">{t.contact.formTitle}</h3>
                    
                    {isSent ? (
                        <div className="flex flex-col items-center justify-center h-64 text-center animate-fade-in">
                            <div className="w-16 h-16 bg-brand-500/10 text-brand-500 rounded-full flex items-center justify-center mb-4 border-2 border-brand-500 shadow-[0_0_20px_rgba(239,68,68,0.4)]">
                                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                            </div>
                            <h4 className="text-xl font-black text-white uppercase mb-2 tracking-wide">{t.contact.successTitle}</h4>
                            <p className="text-neutral-400">{t.contact.successDesc}</p>
                        </div>
                    ) : (
                        <form onSubmit={handleContactSubmit} className="space-y-5">
                            <div className="grid md:grid-cols-2 gap-5">
                                <div className="space-y-2">
                                    <label className="text-xs font-bold text-neutral-500 uppercase tracking-widest">{t.contact.labels.name}</label>
                                    <input 
                                        type="text" 
                                        required
                                        value={contactForm.name}
                                        onChange={e => setContactForm({...contactForm, name: e.target.value})}
                                        className="w-full bg-black border border-neutral-700 text-white px-4 py-3 focus:border-brand-500 outline-none transition-all placeholder:text-neutral-700 focus:shadow-[0_0_15px_rgba(239,68,68,0.2)]"
                                        placeholder={t.contact.placeholders.name}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <label className="text-xs font-bold text-neutral-500 uppercase tracking-widest">{t.contact.labels.email}</label>
                                    <input 
                                        type="email" 
                                        required
                                        value={contactForm.email}
                                        onChange={e => setContactForm({...contactForm, email: e.target.value})}
                                        className="w-full bg-black border border-neutral-700 text-white px-4 py-3 focus:border-brand-500 outline-none transition-all placeholder:text-neutral-700 focus:shadow-[0_0_15px_rgba(239,68,68,0.2)]"
                                        placeholder={t.contact.placeholders.email}
                                    />
                                </div>
                            </div>
                            <div className="grid md:grid-cols-2 gap-5">
                                <CustomSelect 
                                    label={t.contact.labels.type}
                                    value={contactForm.projectType}
                                    onChange={(val) => setContactForm({...contactForm, projectType: val})}
                                    options={projectTypeOptions}
                                />
                                <CustomSelect 
                                    label={t.contact.labels.budget}
                                    value={contactForm.budget}
                                    onChange={(val) => setContactForm({...contactForm, budget: val})}
                                    options={budgetOptions}
                                />
                            </div>

                            {(contactForm.budget === 'custom' || contactForm.budget === 'je_sais_pas') && (
                                <div className="animate-slide-up space-y-2">
                                    <label className="text-xs font-bold text-neutral-500 uppercase tracking-widest">{t.contact.labels.precision}</label>
                                    <input 
                                        type="text" 
                                        value={contactForm.customBudget}
                                        onChange={e => setContactForm({...contactForm, customBudget: e.target.value})}
                                        className="w-full bg-black border border-brand-800 text-brand-500 font-bold px-4 py-3 focus:border-brand-500 outline-none transition-all placeholder:text-neutral-700"
                                        placeholder={t.contact.placeholders.precision}
                                    />
                                </div>
                            )}

                            <div className="space-y-2">
                                <label className="text-xs font-bold text-neutral-500 uppercase tracking-widest">{t.contact.labels.message}</label>
                                <textarea 
                                    required
                                    rows={4}
                                    value={contactForm.message}
                                    onChange={e => setContactForm({...contactForm, message: e.target.value})}
                                    className="w-full bg-black border border-neutral-700 text-white px-4 py-3 focus:border-brand-500 outline-none transition-all placeholder:text-neutral-700 resize-none focus:shadow-[0_0_15px_rgba(239,68,68,0.2)]"
                                    placeholder={t.contact.placeholders.message}
                                ></textarea>
                            </div>
                            <button 
                                type="submit"
                                disabled={isSubmitting}
                                className="w-full bg-brand-600 hover:bg-brand-500 text-white py-4 font-black uppercase tracking-widest transition-all shadow-[0_0_20px_rgba(220,38,38,0.4)] hover:shadow-[0_0_30px_rgba(220,38,38,0.6)] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                            >
                                {isSubmitting ? (
                                    <>
                                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                                        {t.contact.sending}
                                    </>
                                ) : (
                                    <>
                                        {t.contact.btn}
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
                                    </>
                                )}
                            </button>
                        </form>
                    )}
                </div>
            </RevealOnScroll>
         </div>
      </section>

      <footer className="relative z-10 py-8 bg-black border-t border-neutral-900 text-center">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-neutral-500 text-sm font-medium">© {new Date().getFullYear()} Yahiaoui Systems. All rights reserved.</p>
          <div className="flex gap-6 text-sm font-bold uppercase tracking-widest text-neutral-600">
             <a href="#" onClick={(e) => { e.preventDefault(); setIsLegalOpen(true); }} className="hover:text-brand-500 transition-colors">Mentions Légales</a>
             <a href="#" onClick={(e) => { e.preventDefault(); setIsCGVOpen(true); }} className="hover:text-brand-500 transition-colors">CGV</a>
          </div>
        </div>
      </footer>

      {/* CHAT WIDGET CONTAINER - FIXED BOTTOM LEFT */}
      <div className="fixed bottom-6 left-6 z-[9999] flex flex-col items-start gap-4 font-sans pointer-events-auto">
        
        {/* EXPANDED CHAT WINDOW */}
        {isOpen && (
           <div className="w-[350px] md:w-[400px] h-[500px] bg-black/95 backdrop-blur-xl border border-brand-500/50 rounded-2xl shadow-2xl flex flex-col overflow-hidden animate-slide-up origin-bottom-left relative pointer-events-auto">
              
              {/* Header */}
              <div className="flex items-center justify-between p-4 border-b border-brand-900/50 bg-neutral-900/50">
                  <div className="flex items-center gap-3">
                      <div className="relative">
                          <div className={`w-2.5 h-2.5 rounded-full ${state === 'connected' ? 'bg-green-500 animate-pulse' : state === 'error' ? 'bg-red-500' : 'bg-neutral-500'}`}></div>
                      </div>
                      <div>
                          <h3 className="text-white font-black uppercase tracking-wider text-sm">{agentName || 'Agent YS'}</h3>
                          <span 
                            className={`text-[10px] font-bold uppercase tracking-widest cursor-pointer hover:underline ${state === 'error' ? 'text-red-500' : 'text-brand-500'}`}
                            onClick={state === 'error' ? handleReconnect : undefined}
                          >
                             {state === 'connected' ? t.chat.online : state === 'connecting' ? t.chat.connecting : state === 'error' ? t.chat.error : t.chat.offline}
                          </span>
                      </div>
                  </div>
                  <div className="flex items-center gap-2">
                     <button onClick={handleReconnect} className="p-1 text-neutral-400 hover:text-white transition-colors" title="Reconnect">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/></svg>
                     </button>
                     <button onClick={() => setIsOpen(false)} className="text-neutral-400 hover:text-white transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                     </button>
                  </div>
              </div>

              {/* Messages Area */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin scrollbar-thumb-neutral-800 scrollbar-track-transparent">
                  {messages.length === 0 && (
                      <div className="h-full flex flex-col items-center justify-center text-center opacity-40">
                          {state === 'error' ? (
                              <div className="text-red-500 mb-2">
                                  <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
                              </div>
                          ) : (
                              <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" className="mb-2 text-brand-500"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
                          )}
                          <p className="text-sm font-medium">{state === 'error' ? "Connexion impossible." : t.chat.empty}</p>
                          {state === 'error' && (
                              <button onClick={handleReconnect} className="mt-4 px-4 py-2 bg-neutral-800 rounded-full text-xs font-bold uppercase tracking-wider hover:bg-neutral-700 transition-colors">Réessayer</button>
                          )}
                      </div>
                  )}
                  
                  {messages.map((msg) => (
                      <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                          <div 
                              className={`max-w-[85%] p-3 rounded-2xl text-sm font-medium leading-relaxed shadow-sm animate-fade-in
                              ${msg.role === 'user' 
                                  ? 'bg-neutral-800 text-white rounded-br-none' 
                                  : 'bg-brand-900/40 border border-brand-500/20 text-white rounded-bl-none backdrop-blur-sm'
                              }`}
                          >
                              {msg.text}
                              {msg.videoUrl && (
                                  <div className="mt-3 rounded-xl overflow-hidden border border-brand-500/30">
                                      <video src={msg.videoUrl} controls autoPlay loop className="w-full h-auto" />
                                  </div>
                              )}
                              {msg.imageUrl && (
                                  <div className="mt-3 rounded-xl overflow-hidden border border-brand-500/30">
                                      <img src={msg.imageUrl} alt="Generated Content" className="w-full h-auto" />
                                  </div>
                              )}
                          </div>
                      </div>
                  ))}
                  <div ref={chatEndRef} />
              </div>

              {/* Input Area */}
              <div className="relative p-4 border-t border-brand-900/50 bg-neutral-900/30">
                  
                  {/* IMAGE GEN PANEL */}
                  {showImagePanel && (
                      <div className="absolute bottom-full left-0 w-full bg-neutral-950 border-t border-brand-900/50 p-3 flex items-center justify-between gap-3 animate-slide-up shadow-2xl z-20">
                            <div className="flex items-center gap-2">
                                <span className="text-[10px] font-black uppercase text-neutral-500 tracking-wider">IMG Size</span>
                                <div className="flex bg-neutral-900 rounded-md p-0.5 border border-neutral-800">
                                    {(['1K', '2K', '4K'] as const).map(size => (
                                        <button
                                            key={size}
                                            onClick={() => setImageSize(size)}
                                            className={`px-3 py-1 text-[10px] font-bold rounded-sm transition-all ${imageSize === size ? 'bg-brand-600 text-white shadow-md' : 'text-neutral-400 hover:text-white'}`}
                                        >
                                            {size}
                                        </button>
                                    ))}
                                </div>
                            </div>
                            <button 
                                onClick={handleImageGen}
                                disabled={!inputValue.trim()}
                                className="px-4 py-1.5 bg-white text-black text-xs font-black uppercase tracking-wider hover:bg-brand-500 hover:text-white transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                Generate
                            </button>
                      </div>
                  )}

                  <div className="flex items-center gap-2">
                      <button 
                          onClick={triggerFileUpload}
                          disabled={state !== 'connected'}
                          className="p-2 text-neutral-400 hover:text-brand-500 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                          title={t.chat.genVideo}
                      >
                          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg>
                      </button>
                      
                      {/* IMAGE GEN BUTTON */}
                      <button 
                          onClick={() => setShowImagePanel(!showImagePanel)}
                          disabled={state !== 'connected'}
                          className={`p-2 transition-colors ${showImagePanel ? 'text-brand-500 bg-brand-500/10 rounded-lg' : 'text-neutral-400 hover:text-brand-500'} disabled:opacity-30 disabled:cursor-not-allowed`}
                          title={t.chat.genImage}
                      >
                          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg>
                      </button>

                      <input 
                          type="file" 
                          ref={fileInputRef} 
                          className="hidden" 
                          accept="image/*" 
                          onChange={handleFileChange} 
                      />

                      {/* MIC MUTE BUTTON */}
                      <button
                          onClick={toggleMute}
                          disabled={state !== 'connected' || !hasMicAccess}
                          className={`p-2 transition-all rounded-full border border-transparent 
                            ${isMuted 
                              ? 'text-red-500 bg-red-500/10 border-red-500/30 hover:bg-red-500/20' 
                              : 'text-neutral-400 hover:text-brand-500 hover:bg-neutral-800'
                            } disabled:opacity-30 disabled:cursor-not-allowed`}
                          title={isMuted ? "Unmute" : "Mute"}
                      >
                         {isMuted ? (
                             <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="1" y1="1" x2="23" y2="23"></line><path d="M9 9v3a3 3 0 0 0 5.12 2.12M15 9.34V4a3 3 0 0 0-5.94-.6"></path><path d="M17 16.95A7 7 0 0 1 5 12v-2m14 0v2a7 7 0 0 1-.11 1.23"></path><line x1="12" y1="19" x2="12" y2="23"></line><line x1="8" y1="23" x2="16" y2="23"></line></svg>
                         ) : (
                             <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path><path d="M19 10v2a7 7 0 0 1-14 0v-2"></path><line x1="12" y1="19" x2="12" y2="23"></line><line x1="8" y1="23" x2="16" y2="23"></line></svg>
                         )}
                      </button>
                      
                      <div className="flex-1 relative">
                          <input
                              type="text"
                              value={inputValue}
                              onChange={(e) => setInputValue(e.target.value)}
                              onKeyDown={handleKeyPress}
                              disabled={state !== 'connected'}
                              placeholder={state === 'connected' 
                                ? (hasMicAccess ? (isMuted ? "Micro coupé, écrivez..." : t.chat.placeholder) : t.chat.placeholderNoMic) 
                                : t.chat.connectPlaceholder}
                              className="w-full bg-black/50 border border-neutral-700 rounded-full pl-4 pr-10 py-2.5 text-sm text-white focus:border-brand-500 focus:outline-none focus:ring-1 focus:ring-brand-500 transition-all placeholder:text-neutral-600 disabled:opacity-50"
                          />
                          <button 
                              onClick={() => handleSend()}
                              disabled={!inputValue.trim() || state !== 'connected'}
                              className="absolute right-1 top-1/2 -translate-y-1/2 p-1.5 bg-brand-600 text-white rounded-full hover:bg-brand-500 disabled:bg-neutral-800 disabled:text-neutral-600 transition-all"
                          >
                              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
                          </button>
                      </div>
                  </div>
              </div>
           </div>
        )}

        {/* TOGGLE BUTTON (FAB) */}
        <div className="flex items-center gap-4 pointer-events-auto">
            <button 
                onClick={toggleWidget}
                className={`
                    group relative w-16 h-16 rounded-full shadow-2xl flex items-center justify-center transition-all duration-300 z-50
                    ${isOpen ? 'bg-neutral-900 border border-neutral-700' : 'bg-black border border-brand-500/50 hover:border-brand-500 hover:shadow-[0_0_30px_rgba(239,68,68,0.5)]'}
                    ${state === 'connected' && !isOpen ? 'animate-pulse-subtle shadow-[0_0_20px_rgba(239,68,68,0.4)]' : ''}
                    ${state === 'error' && !isOpen ? 'border-red-500 shadow-[0_0_20px_rgba(220,38,38,0.6)] animate-pulse' : ''}
                `}
            >
                {/* Notification Badge */}
                {!isOpen && state === 'connected' && (
                    <span className="absolute top-0 right-0 w-4 h-4 bg-brand-500 rounded-full border-2 border-black z-20 animate-bounce"></span>
                )}
                {!isOpen && state === 'error' && (
                    <span className="absolute top-0 right-0 w-4 h-4 bg-red-500 rounded-full border-2 border-black z-20"></span>
                )}

                <div className="relative z-10 pointer-events-none">
                     <Visualizer 
                        isActive={isSpeaking} 
                        volume={volume} 
                        state={state} 
                        mode="widget" 
                     />
                     {/* Show mic muted/disabled status on FAB */}
                     {(!hasMicAccess || (state === 'connected' && isMuted)) && (
                         <div className="absolute -bottom-2 -right-2 bg-neutral-900 border border-neutral-700 rounded-full p-1 text-red-500" title={!hasMicAccess ? "Microphone Disabled" : "Microphone Muted"}>
                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="1" y1="1" x2="23" y2="23"></line><path d="M9 9v3a3 3 0 0 0 5.12 2.12M15 9.34V4a3 3 0 0 0-5.94-.6"></path><path d="M17 16.95A7 7 0 0 1 5 12v-2m14 0v2a7 7 0 0 1-.11 1.23"></path><line x1="12" y1="19" x2="12" y2="23"></line><line x1="8" y1="23" x2="16" y2="23"></line></svg>
                         </div>
                     )}
                </div>
            </button>
            {!isOpen && (
                <div className="hidden md:block bg-black/80 backdrop-blur-md px-4 py-2 rounded-lg border border-neutral-800 text-xs font-bold uppercase tracking-wider text-white animate-fade-in shadow-lg">
                    {lang === 'fr' ? (state === 'error' ? "Erreur Connexion" : "Discuter avec l'IA") : (state === 'error' ? "Connection Error" : "Chat with AI")}
                </div>
            )}
        </div>
      </div>

    </div>
  );
};

export default App;

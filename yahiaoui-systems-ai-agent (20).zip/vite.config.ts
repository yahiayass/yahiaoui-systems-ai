
import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, '.', '');

  // CLÉ API CONFIGURÉE POUR YAHIAOUI SYSTEMS
  // Note: Pensez à restreindre cette clé au domaine https://yahiaouisystems.com/ sur Google Cloud Console.
  const HARDCODED_KEY = 'AIzaSyDtnGEYNkmbIh-QcDpYiR8-biO8EW3p3gs';
  
  // Priorité : Variable d'env > Clé Hardcodée
  const finalKey = env.API_KEY || env.VITE_API_KEY || HARDCODED_KEY;

  return {
    plugins: [react()],
    server: {
      host: true
    },
    define: {
      // Injection de la clé pour l'application
      'process.env.API_KEY': JSON.stringify(finalKey),
    }
  };
});
